# Doctrine Labs — Zoe Companion: End-to-End Build & Launch Blueprint (v1)

*Prepared for Brandon Flores + Adam, Doctrine Labs — September 24, 2026. This is the full operational checklist: entity, legal, payments, compliance, security, insurance, IP, customer operations, scale, and the influencer sequence. Where it lives in the repos: the public engine stays in `zoe`; this operations layer lives in a new `zoe-goes-wild/OPERATIONS/` directory in the separate (adult) repo, keeping the Doctrine Labs-facing properties clean.*

**Status labels on every item (your own discipline): PROVED / BUILT / PARTIAL / HYPOTHESIS / PLANNED.** Nothing ships past its label.

---

## Phase 0 — Foundation (Weeks 1–4, parallel with demo build)

**0.1 Entity & ownership**
- [ ] Decide the companion's public name (Zoe Goes Wild candidate; must not collide with Zoe Medical or the Doctrine Labs brand — run a trademark search before committing)
- [ ] Form LLC (Delaware or Oregon; separate from Doctrine Labs entity) — registered agent, EIN, operating agreement
- [ ] **IP assignment agreement, signed by Brandon and Adam, covering all existing and future work on the companion** — *before the demo exists, not after*. This is the single most common two-person founder failure, and the explicit content makes the asset more contestable, not less.
- [ ] Open business bank account; set up bookkeeping (QuickBooks-class)

**0.2 Legal documentation (attorney-reviewed; do not template this alone)**
- [ ] Terms of Service (18+ hard wall, no-minors clause, arbitration, content-policy incorporated by reference)
- [ ] Privacy Policy (what you collect, what stays local, breach notification)
- [ ] Refund Policy (chargeback-mitigation critical: clear refund path = fewer disputes)
- [ ] 18 U.S.C. §2257 record-keeping posture (age/consent documentation for any real-person content; even for fully synthetic, maintain the compliance floor — processors audit for it)
- [ ] COPPA wall (13+ absolute; 18+ for restricted content)
- [ ] DMCA agent registration ($6, U.S. Copyright Office) + repeat-infringer policy
- [ ] Content Policy v1 (no minors — absolute, no violence, no non-consent themes, all synthetic consent documented; the Zoe "welded rails" pattern applied to the adult lane: **these rails never change with a persona switch**)

**0.3 Technical pre-work (parallel track)**
- [ ] Complete the `zoe` demo path: voice-in (whisper) → intent → SadTalker-animated strip sequence → SDXL scene state. Components exist; integration + latency tuning is the work (target <6s round-trip on M1 Max)
- [ ] Separate the adult persona + scene logic out of the public `zoe` repo into the separate adult repo (`zoe-goes-wild`) from day one — **never let the explicit lanes share git history, assets, or brand surface with the Zoe Medical / Doctrine Labs properties** (this is your own motionforge R9 doctrine rule; enforce it at the repo level)
- [ ] Decide the architecture split: what runs local (privacy story, your brand) vs. cloud (scale). Recommendation: persona/memory local; rendering/scene generation cloud (GPU-bound); document the split publicly — "your memories never leave your device" is a differentiator in a category that leaked 343M+ messages

## Phase 1 — Money & Compliance (Weeks 3–8, before any charge)

**1.1 Payments (the chargeback-proof stack)**
- [ ] Apply for high-risk merchant account: start CCBill (fast onboarding, ~10.8–14.5% all-in) OR MobiusPay-class own account (~4.25–7.60% + ~2% gateway + reserve). Budget $1,500–3,000 setup. Have ready: entity docs, EIN, voided check, processing history (if any), 2257 posture, content policy
- [ ] Register with Visa ($950/yr) and Mastercard ($1,000/yr) high-risk programs (usually handled by the processor)
- [ ] Wire in Verifi RDR + Ethoca Alerts (pre-dispute interception; ~$0.20–0.35 effective per transaction) — *this is the "digital cashier's check" behavior: the money gets pulled back by rule before it becomes a chargeback*
- [ ] Instrument checkout for Compelling Evidence 3.0 from transaction #1: browser device fingerprint + client IP + user ID + consistent billing descriptor. **Server logs do not qualify.** This qualifies Visa fraud disputes for automatic liability shift after 2 prior undisputed transactions
- [ ] Age verification gate: Didit ($0.10/check, self-serve, white-label) or Veriff ($0.80/check + $49/mo min) — **must run before any restricted content, and the verification record must be retained**
- [ ] Optional rails for annual/large payments: ACH debit or wire (zero chargeback exposure; your highest-LTV segment pays this way)
- [ ] Exclude: card-to-crypto settlement (Stripe/Bridge, BVNK) — content-policy rules follow the same Visa/MC restrictions; no advantage, added tax complexity

**1.2 Financial operations**
- [ ] Rolling reserve plan: expect 5–10% held 90–180 days; model working capital accordingly
- [ ] Chargeback-response runbook: representment templates, evidence packet assembly (CE3.0 data, session logs, age-verification record), refund-before-dispute SLA
- [ ] Weekly chargeback-ratio review (hard ceiling 0.9% — VAMP threshold; the hot-tub lesson)

## Phase 2 — Security, Insurance, Trust (Weeks 4–10, before real user data)

**2.1 Security**
- [ ] External penetration test ($4,000–12,000, grey-box web+API scope) — your in-house red-team harness is necessary but not sufficient for a product holding intimate data
- [ ] Encryption at rest (AES-256) + in transit (TLS 1.3); key management documented
- [ ] User data: deletion API (GDPR/CCPA), export API, retention schedule, breach-response plan
- [ ] Session/usage logging — this doubles as CE3.0 evidence and as subscription continued-usage evidence for cancellation disputes
- [ ] SOC 2: not needed at launch; start the controls now (you'll need it for Zoe Medical enterprise anyway — shared work)

**2.2 Insurance**
- [ ] Cyber liability (median $1,552/yr small business; budget $2–3K adult-adjacent) + Tech E&O if bundled cheaper. **Disclose the adult content to the broker** — a denied claim from nondisclosure is worse than no insurance

**2.3 Trust & Safety operations**
- [ ] Content-moderation tooling (automated + human review queue for edge cases)
- [ ] NCII (non-consensual intimate imagery) takedown SLA: 48-hour removal, published contact
- [ ] CSAM zero-tolerance: detection, reporting (NCMEC CyberTipline), never-train-on policy
- [ ] Support workflows: billing, content-policy appeals, safety escalation

## Phase 3 — Launch (Months 3–4)

**3.1 Soft launch (clean tiers)**
- [ ] Public beta: Standard ($15/mo) + Premium ($40/mo) — **no explicit sessions yet**
- [ ] Instrument the 5 metrics from day one: free→paid by tier, 30-day retention, Premium attach, CAC by channel, chargeback rate
- [ ] Community/feedback loop: the Doctrine Labs claims-discipline culture applied publicly (PROVED/BUILT/HYPOTHESIS labels on roadmap items)

**3.2 Explicit tier (only when the stack is proven)**
- [ ] Add sessions ($100/5-min) once: age-verification live 30+ days clean, chargeback rate <0.5%, processor relationship stable
- [ ] Session attach tracking (validates the 15–25% assumption in the revenue model)

**3.3 The Galloway / influencer sequence (credibility, not launch)**
- [ ] Sequence: working demo (M2) → legal entity + clean beta (M3–4) → *then* outreach. Influencers need a live, safe, working product to point at
- [ ] The pitch frame for Galloway (his thesis is the loneliness/social-skills crisis in young men): **"Zoe is a social-confidence coach. The wellness tier teaches men to socialize; the intimate tier is the adult expression of the same human need. Local-first, privacy-preserving, priced 50–70% below the token-gouging incumbents, with deterministic rails: no minors, no violence, welded into every persona."** Lead with the wellness mission; the explicit tier is disclosed, not lead
- [ ] Target list beyond Galloway: relationship/social-skills educators, men's-health voices, the "AI for good" podcaster circuit. **Avoid:** the pure adult-industry influencer circuit at launch — it confirms the worst frame before the wellness frame is set
- [ ] One public artifact for them to link: the Five Gates + doctrine page (the "tool AI vs. replacement AI" honesty is the differentiating story)

## Phase 4 — Scale (Months 6–24)

**4.1 Growth (web-only funnel — no app stores)**
- [ ] Content engine (short-form video: the demo clips are inherently viral if tastefully cut — the "she strips when you ask" moment, framed as technical achievement)
- [ ] Referral program (the category's cheapest CAC channel)
- [ ] SEO/community (the loneliness/social-skills content overlap)
- [ ] Capacity: GPU rendering fleet scaling plan (cloud, cost/user at video-heavy load $3–8/mo — monitor against the $40 Premium price)

**4.2 Triggers that change the model**
- [ ] Free→paid ≥6% blended + 30-day retention ≥70% → scale spend (MEDIUM scenario alive)
- [ ] Chargebacks >0.7% sustained → pause acquisition, fix the funnel before VAMP flags
- [ ] Premium attach ≥25% + sessions 2/mo → the ARPPU band ($460) validates the HIGH scenario
- [ ] At 10K+ paying subs → hire Trust & Safety + support (first employees)

**4.3 The enterprise/medical track (parallel, separate)**
- [ ] Zoe Medical pilot at Utah stays on the clean Doctrine Labs track — separate repo, separate brand surface, separate payment story. The two Zoes never cross

---

## What this document deliberately excludes

- Templates (TOS, privacy policy, operating agreement) — these must come from your attorney, not a checklist
- Named processor promises (CCBill/MobiusPay underwriting decides, not us)
- Revenue projections (in the separate roadmap document)
- Anything that assumes the explicit tier launches on day one (it launches when the stack is proven)

*Blueprint v1 — attack any phase and we revise.*
