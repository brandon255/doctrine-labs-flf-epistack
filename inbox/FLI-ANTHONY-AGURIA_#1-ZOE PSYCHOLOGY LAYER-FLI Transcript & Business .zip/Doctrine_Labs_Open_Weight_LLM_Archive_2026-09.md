# Doctrine Labs — Open-Weight LLM Archive
## An archivist's census of editable local models, with a fit assessment for Zoe's four layers

**Compiled:** September 25, 2026
**Archivist's standing:** This document is a research artifact, not a launch decision. Every load-bearing claim carries a discipline label consistent with the Doctrine Labs corpus schema (PROVED / BUILT / PARTIAL / CORRELATIONAL / HYPOTHESIS / PLANNED). Where sources conflict, the conflict is registered rather than smoothed over.

**Method note (metacognition):** The open-weights landscape moves weekly. Vendor benchmark claims are treated as *claims*, not facts. License terms are treated as facts only when confirmed by a second source or the model card itself. Anything I could not verify from at least a B-authority source is labeled PARTIAL or flagged inline. Benchmark numbers are deliberately de-emphasized — per the operator's read of the OpenRouter board, usage rankings measure popularity, not quality, and generic benchmarks routinely reverse on domain-specific tasks. The right model is the one that wins on *your* data.

---

## PART 1 — THE CENSUS: WHAT EXISTS AND WHAT YOU MAY DO WITH IT

### 1.1 License reality first (this is the archivist's hard line)

"Open source" in AI currently means three different things, and the difference determines what Doctrine Labs can legally build:

1. **True permissive (Apache 2.0 / MIT)** — use commercially, fine-tune, merge, redistribute, sublicense, no caps, no reporting. This is the only tier where "pull out what we don't need and keep what they've trained" is unambiguously yours afterward.
2. **Custom "community" licenses** — commercial use allowed *with conditions* (MAU caps, attribution, acceptable-use policies baked in, terms mutable by the vendor).
3. **Open-weight only** — weights downloadable, but redistribution of derivatives restricted or terms changeable retroactively (Gemma ≤3, historically).

**BUILT (PROVED):** The license tier table as of September 2026:

| Tier | Models | Key conditions |
|---|---|---|
| **Apache 2.0 / MIT — clean** | Gemma 4 (all sizes, incl. 12B Unified multimodal), Qwen 3 / 3.5 / 3.6 family, Mistral Small 3.x / Small 4 / Ministral, GPT-OSS-20B & 120B (OpenAI), Phi-4 (MIT), OLMo-2 7B/32B (AI2), Granite 3.3/4.0 (IBM), GLM-4.5-Air & 4.7-Flash (MIT), Kimi-Linear-48B-A3B (MIT), Ling-2.6-flash (MIT), Step-3.5-Flash, DeepSeek R1 + all R1-distills (MIT), Falcon-H1 (custom, check terms) | None material. Attribution + license text. Patent grant included (Apache 2.0). |
| **Custom community — usable with conditions** | Llama 3.2 / 3.3 / 4 Scout / 4 Maverick (Meta), Kimi K2 / K2.5 / K2.6 / K3 (Moonshot), Mistral Medium 3.5 (Modified MIT w/ revenue cap), StarCoder 2 (Open RAIL-M) | Llama: <700M MAU, "Built with Llama" naming, AUP. Kimi K2 family: Modified MIT — free commercial use below 100M MAU or $20M MRR; visible credit required above; **synthetic-data clause: models trained on K2 output do NOT inherit the license**. Mistral Medium 3.5: revenue cap. |
| **Avoid for Doctrine Labs** | Codestral 22B (MNPL — non-commercial), Gemma ≤3 (old ToU, terms mutable retroactively), anything Open RAIL-M where the use-restriction list collides with adult content | — |

**PROVED (multiple independent B+ sources, April 2026):** Google's Gemma 4 moved the whole family from the custom Gemma Terms of Use to standard Apache 2.0 — the single biggest licensing event in the open-weights world this year, because it removed the "Google can change terms on deployed models" and "derivative models inherit restrictions" problems that made Gemma 1–3 radioactive for enterprise legal review. Gemma 4 ships in four sizes: E2B, E4B (edge, native audio), 26B MoE, and 31B dense; 128K–256K context; encoder-free multimodal on the 12B Unified variant.

**PARTIAL (single-source, verify on model card before committing):** Qwen3.6 35B A3B existence and specs (strong sourcing from a hardware-fit site, but treat exact numbers as provisional); Kimi K3 release status (expected July 27, 2026 per pre-release reporting; a September 20, 2026 industry roundup lists it as released under its own model license — confirm on github.com/MoonshotAI before planning around it).

### 1.2 The current quality frontier, size tier by size tier

Numbers below are vendor/tracker claims, not gospel. They are included to orient, not to decide.

**Edge / on-device (1–4B):**
- Llama 3.2 1B/3B (Llama Community; text-only EU-OK; the 3B is the strongest tiny model with the deepest recipe library)
- Gemma 4 E2B / E4B (Apache 2.0; native audio; purpose-built for on-device)
- Phi-4 14B (MIT) and Phi-2 2.7B — small-model reasoning specialists
- Falcon-H1-1.5B, Pleias-RAG-350M/1B (100% public-domain training data, native citation — interesting for the Doctrine corpus's provenance discipline)

**Laptop-class sweet spot (7–35B) — this is the Doctrine Labs tier:**
- **Qwen 3.5-27B / 3.5-9B / 3.6-27B / 3.6-35B A3B** — Apache 2.0, 128K–262K context, 201-language coverage on 3.5, MoE variants with tiny active-parameter footprints. The 3.6 35B A3B (3B active) is currently the best speed/quality fit for a 64GB Apple Silicon machine at ~31 tok/s.
- **Gemma 4 31B dense** — Apache 2.0, 256K context, #3 on Arena ELO among open models per vendor claims, 23–28 tok/s MLX on M1 Max. The 12B Unified variant is encoder-free multimodal with native audio.
- **Mistral Small 4** (119B total / 6B active MoE, Apache 2.0, 256K) and **Mistral Small 3.1** — unified instruct/reasoning/coding checkpoints.
- **GLM-4.7-Flash** (30B total / 3B active MoE, MIT, 200K) — agentic coding strength per vendor.
- **Hermes 4-70B** (Nous Research, Llama Community base) — hybrid reasoning, tool-calling; tracker lists it as SOTA on refusal-behavior benchmarks, which cuts both ways for our use case (see Part 4).
- **DeepSeek R1-Distill-32B / QwQ-32B** — MIT/Apache reasoning RL models; 32B dense, beats o1-mini on math per vendor.

**Server-class (70B+ — RunPod territory):**
- **Llama 3.3 70B** — the ecosystem default; deepest fine-tune recipe library in existence.
- **GPT-OSS-120B** (5.1B active MoE, Apache 2.0, adjustable `reasoning_effort`) — the most interesting orchestration candidate of the year; OpenAI released it open-weight under Apache 2.0. The 20B sibling (3.6B active) **fits in 16GB** — laptop-deployable.
- **Kimi K2.6** — 1T total / 32B active MoE, 256K context, native multimodal incl. video, Agent Swarm (300 sub-agents / 4,000 coordinated steps). Modified MIT. Self-hosting needs ~594GB (native INT4) → minimum 4× H100, recommended 8× H200. This is a datacenter model, not a RunPod pod model.
- **Step-3.5-Flash** (196B/11B active, Apache 2.0, 262K, 350 tok/s claims), **Ling-2.6-flash** (MIT, token-efficient agent), **MiniMax M2.7** (MIT per tracker, verify).
- **Kimi K3** — 2.8T total / ~50B active per pre-release reporting; own model license; not local-machine viable by any stretch.

**Vision-language (for the image-training thread):**
- **Qwen3-VL 30B A3B** — ~34 tok/s on an M1 Max 64GB per hardware-fit reporting; strong document/screenshot understanding.
- **InternVL3** (1B→78B, Apache 2.0; MMMU 72.2 on 78B per vendor) — check per-checkpoint terms; tracker warns InternVL can inherit component licenses.
- **MiniCPM-V / MiniCPM-o 4.5** (Apache 2.0; edge-capable omni-modal), **Molmo 2** (AI2, Apache 2.0), **Gemma 4 12B Unified** (Apache 2.0, native audio + vision), **Kimi-VL** (open).
- Caution from the tracker: "InternVL checkpoints can inherit terms from their underlying components" — read each model card before commercial use.

**Long-context specialists:**
- Llama 4 Scout — 10M context (Llama Community; multi-GPU serving).
- Kimi-Linear-48B-A3B — MIT, **1M context**, 5.7T tokens, hybrid linear attention (3 KDA layers : 1 MLA). Proof that linear attention can match full attention. 3B active → surprisingly servable.
- Qwen3.5 largest — ~1M context per vendor claims.

**Alternative architectures (HYPOTHESIS-tier interest for Doctrine's "nothing industry standard" instinct):**
- Granite 4.0 — 90% Mamba-2 / 10% attention, 70% memory reduction, 2× speed (Apache 2.0).
- ZAYA1-8B — hybrid Mamba + compressed cross-attention, **9% active parameters**, on-device, 128K (Apache 2.0).
- Jamba 1.6 Mini — Mamba+Transformer+MoE, 2.5× transformer speed.
- URM — recursive universal transformer; ARC-AGI 1: 53.8% per author claims (research license).

---

## PART 2 — THE EDITABILITY TOOLKIT: HOW YOU ACTUALLY "PULL OUT WHAT YOU DON'T NEED"

The user's instinct — *take their training, discard the rest* — has four mature mechanical implementations in 2026. All four apply to any Apache 2.0 / MIT model in Part 1.

### 2.1 LoRA / QLoRA adapters (the workhorse) — BUILT

Freeze the base weights; train small adapter matrices (0.1–1% of parameters) on your data. Merge or hot-swap at inference. Quality retention 95–98% of full fine-tuning at 30–40% of the VRAM. One base model can host a **persona adapter, a social-intelligence adapter, an explicit-content adapter, and a wellness-mode adapter** — four layers, one brain, exactly matching Zoe's architecture. Multi-adapter serving exists (dozens of adapters on one GPU).

- Toolchain: **Unsloth** (Apache 2.0 core; claims 2× training speed, 70% less VRAM, 12× faster MoE training; $0 on your own GPU), **Axolotl** (Apache 2.0; config-file-driven; LoRA/QLoRA/full/DPO/IPO/KTO/ORPO/GRPO; FSDP2 + DeepSpeed for multi-GPU), **torchtune**. Training styles: SFT → DPO → KTO/ORPO for preference shaping (the ladder that maps to "less refusal / more character-consistent" shaping).
- Verified cost anchors (September 2026): Fireworks LoRA SFT at **$0.50 per 1M training tokens ≤16B** ($3.00 for 16–80B); 30M-token job on a 70B ≈ **$90**. io.net: 7B LoRA **$5–20**, 70B **$100–400**. Spheron A100 pricing: 7B QLoRA run **$1.10–2.20**, 70B QLoRA **$10.64–15.96**, full 70B fine-tune on 8× H100 **$255–510**. The dataset labor, not the GPU bill, is the real cost — one source states this outright.
- On the existing RunPod 4090-class pod: 7–9B QLoRA is an overnight job; 27–35B needs A100/H100 rental hours.

### 2.2 Model merging (weight-space surgery, no training) — BUILT

**MergeKit** (Arcee AI, de facto standard) combines checkpoints directly in weight space:
- **SLERP** — two models, spherical interpolation. The right tool for exactly two parents (e.g., base + character fine-tune).
- **TIES** — 3+ models: trim low-magnitude deltas, elect one sign per parameter, merge only agreeing parameters. Fixes sign conflicts between fine-tunes.
- **DARE / DARE-TIES** — random-drop + rescale each delta first; best all-around for multi-model merges.
- **Task Arithmetic** — add/subtract task vectors: *add* a capability or **subtract a behavior**. This is the literal mechanical implementation of "pull out what we don't need" — capabilities are directions in weight space and can be subtracted, not just trained away.
- **Passthrough** — copy layers to build Franken-MoEs.
- Runs on CPU-only hardware; merges are nearly free. Community practice: thousands of merged checkpoints on Hugging Face; evolutionary hyperparameter search exists for critical applications.

### 2.3 Refusal surgery (abliteration / heretic) — PROVED as technique, CORRELATIONAL on quality

The load-bearing fact for the explicit-content layer: aligned open models carry a measurable **refusal direction** in activation space (Arditi et al. 2024). Removing it is linear algebra, not retraining:

- **Abliteration** — compute mean(harmless) − mean(harmful) activations per layer, orthogonalize weight matrices against that direction. Irreversible, persists across prompts, weights otherwise intact. Abliterated variants of Llama 3.x, Qwen 2.5/3, Mistral, Gemma appear on Hugging Face within hours of each release.
- **Heretic** (late 2025) — automates abliteration with per-layer tuning, co-minimizing refusals and KL divergence vs. base. A shipped Qwen3 4B Heretic publishes KL 0.43.
- **Uncensored fine-tunes** (Dolphin family and kin) — the alternative path: train on refusal-filtered data so the model never learns refusal. Changes style/personality along the way (feature and bug, depending on layer).
- Honest limitations, stated by the practitioners themselves: an uncensored model is *not* smarter or better — it is the same weights with one behavior subtracted; quality drift varies by checkpoint; and **safety policy belongs at the application layer** (policy rules, audit, moderation) — which is precisely Doctrine's existing architecture: the jailbreaker WALL and character layer are application-layer controls. This convergence should be noted: the field has arrived at Doctrine's design.

### 2.4 Quantization (the shipping format) — BUILT

GGUF via llama.cpp remains the portable standard (Ollama, LM Studio, Jan all load it); over 60% of quantized models on Hugging Face ship GGUF now. Q4_K_M is the quality/size sweet spot; imatrix calibration makes aggressive Q2/IQ quants viable. AWQ/GPTQ for vLLM serving instead. On Apple Silicon, **MLX** (Apple's own framework) typically beats llama.cpp by 10–50% on generation speed. llama-server exposes an OpenAI-compatible endpoint from a single binary — the drop-in replacement layer for any OpenAI-shaped code already written.

---

## PART 3 — HARDWARE REALITY: THE TWO MACHINES DOCTRINE ACTUALLY HAS

### 3.1 The M1 Max 64GB (founder laptop) — PROVED fit envelope

- Unified memory 64GB, 400GB/s bandwidth. macOS caps GPU-usable RAM at ~75% by default; `sudo sysctl iogpu.wired_limit_mb=57344` raises it to 56GB.
- **Verified-tier fits:** Qwen 3.6 35B A3B ≈ 31 tok/s (best current match); Qwen3-VL 30B A3B ≈ 34 tok/s; Gemma 4 31B MLX ≈ 23–28 tok/s; 7–9B Q4 models at 30–35 tok/s.
- **Stretch fits:** Llama 3.3 70B Q4_K_M ≈ 5.8 tok/s — functional, not delightful. Max practical ~48B params per the hardware-fit tracker.
- Conclusion: the laptop is a genuine development and even demo machine for everything up to ~35B MoE class. Not a trainer (except tiny LoRAs), not a 70B serving box.

### 3.2 The RunPod GPU — PLANNED, sized

- 4090-class (24GB): inference + QLoRA training for ≤13B; the overnight 7B fine-tune box.
- A100 80GB rental: 70B QLoRA ($100–400/run class), or 27–34B full fine-tuning.
- Kimi K2.6-class (594GB INT4): out of scope — that is 4–8 datacenter GPUs, not a pod.

---

## PART 4 — ZOE FIT ASSESSMENT: FOUR LAYERS, FOUR ANSWERS

Recall Zoe's layer stack from the architecture work: (1) persona/character, (2) social intelligence / courtesy / twelve-steps, (3) explicit companion content, (4) orchestration + mode-switching (wellness / companion / explicit, with the jailbreaker WALL and Alliance Gate at the application layer).

### 4.1 Persona & social-intelligence layers — RECOMMENDATION (HYPOTHESIS pending 30-min bake-off)

Shortlist, in order:
1. **Qwen3.5-27B or 3.6-27B/35B-A3B (Apache 2.0)** — best hardware fit on the existing laptop, enormous fine-tune ecosystem, 201-language base (matters for multilingual courtesy corpus later).
2. **Gemma 4 31B (Apache 2.0)** — cleanest license story on earth right now; strong multimodal path via 12B Unified; slightly slower on M1 Max.
3. **Llama 3.3 70B (Llama Community)** — deepest recipe library; the "if Qwen/Gemma miss quality targets, escalate here" option. 700M MAU cap is a non-issue at Doctrine's scale but the naming clause and AUP are permanent obligations.

Method per the operator's read cited above: 50 representative prompts from the actual corpus, run through each candidate, scored blind. Not MMLU. This is a one-afternoon job that prevents a month of regret.

### 4.2 Explicit-content layer — RECOMMENDATION (BUILT mechanics, legal flag stands)

The governing constraint from the founder: **no layer of the coaching/epistack stack may ever block explicit content.** Model choice is where this is won or lost:

- Aligned checkpoints (Hermes 4 is explicitly marketed on refusal-behavior strength) will fight this layer at the weights level. Do not build the explicit adapter on a refusal-proud base.
- Path A (recommended): permissive base (Qwen3.5/3.6 or Gemma 4) → **uncensored-community starting checkpoint or self-run abliteration/heretic** → Doctrine's own DPO on a curated adult corpus → the character layer (not the model) owns boundaries. Zoe's capacity to be offended, to push back, to hold the boundary floor lives in the application layer — which is both the product requirement and, per the safety literature cited in Part 2.3, the architecturally correct place for policy.
- Path B: start from a Dolphin-family uncensored fine-tune (Apache/MIT bases) and LoRA the persona on top.
- The prior-session flags stand unchanged: no training on scraped real-person imagery/video without legal sign-off; the gynecology/intercourse reference material is deferred until legal clears it. Nothing in this document overrides that deferral.

### 4.3 Orchestration / mode-switching layer — RECOMMENDATION (PLANNED)

- **GPT-OSS-20B** (Apache 2.0, fits 16GB — runs on the laptop, adjustable `reasoning_effort`) is the most intriguing mode-switcher candidate: one open checkpoint with a dial maps naturally onto wellness/companion/explicit register selection, and it can run beside the persona model on the same machine.
- **GPT-OSS-120B** or **Qwen3.5-122B-A10B** on RunPod for the full orchestrator with tool-calling.
- **Kimi K2.6** only if the agent-swarm ambition (the "swarm of local agents working around the clock" instinct) survives cost review — its Modified MIT synthetic-data clause means **anything distilled from K2.6 output cannot inherit its license terms**, so K2.6 is a *tool*, never a *teacher*, in Doctrine's pipeline. Given the corpus's provenance discipline, mark this constraint prominently.
- The OpenAI-compatible `llama-server` endpoint is the integration seam — every layer speaks the same API, and adapters hot-swap under it.

### 4.4 Vision layer (image-training thread) — PLANNED, legal-gated

Qwen3-VL 30B A3B or MiniCPM-V as the perception substrate for image-reference grounding; Gemma 4 12B Unified if audio+vision in one edge model is wanted. Fine-tuning a VLM on reference imagery is a QLoRA-class job on rented A100s. **Status unchanged: deferred pending legal clearance.** The hardware can do it today; the permission to do it is what we're waiting on.

---

## PART 5 — COSTED PLAN (all figures from Part 2 anchors)

| Step | Hardware | Cost | Output |
|---|---|---|---|
| 50-prompt bake-off (3 candidates) | laptop, existing | $0 | Ranked base-model pick |
| Persona SFT LoRA, 10–30K dialogue examples, 7–9B | RunPod 4090 or $0.28/hr 4090 rental | $5–40 | Zoe persona adapter v0.1 |
| Social-intelligence DPO (courtesy/twelve-steps corpus) | same | $5–20 | Adapter v0.2 |
| Refusal surgery if base fights the explicit layer | laptop CPU (mergekit/heretic) | $0 | Uncensored base checkpoint |
| Explicit-layer DPO on curated corpus | 4090/A100 rental | $20–100 | Explicit adapter (app-layer WALL governs) |
| Orchestrator eval (GPT-OSS-20B vs Qwen3.5-122B) | laptop + RunPod | $0–50 | Mode-switcher pick |
| **Total to a four-layer local Zoe** | | **~$50–250 of compute** | — |

The expensive line items are not in this table: corpus labor (the etiquette/de-escalation/twelve-steps dataset is the moat), the voice pipeline (XTTS-v2 non-commercial caveat — Coqui's license requires a commercial license for revenue use; budget for ElevenLabs-scale licensing or train from a permissive TTS base), and eval harness labor (the jailbreaker CI suites as pass/fail wall).

---

## PART 6 — RISKS, CONFLICTS, AND HONEST FLAGS (archivist's obligation)

1. **Benchmark inflation.** Most capability numbers in Part 1 are vendor-published. The OpenRouter board measures token volume, i.e., popularity. Treat all benchmark deltas <5 points as noise. (BUILT)
2. **License drift.** Custom licenses (Llama Community, Kimi Modified MIT, Mistral Medium's revenue-capped Modified MIT) can add clauses between versions. Re-read the model card at every version bump. Apache 2.0/MIT models are immune to this — the strongest argument for building Zoe's spine exclusively on Tier-1 licenses. (BUILT)
3. **Qwen size exceptions.** Historical Qwen releases (2.5-era 3B/72B) carried Qwen-license exceptions while siblings were Apache 2.0. Check each checkpoint's card, not the family's reputation. (PARTIAL — pattern documented, per-checkpoint status varies)
4. **Abliteration quality drift.** Community abliterated checkpoints vary wildly; the honest sources say so themselves. Measure KL/refusal tradeoffs or run Heretic yourself rather than trusting a `-abliterated` suffix. (BUILT)
5. **RP-heritage models are dated.** The 2023–24 roleplay canon (MythoMax-L2-13B, Chronos-Hermes, OpenHermes-2.5, Nous-Hermes-Yi-34B) still ranks on RP leaderboards, but these are two-generation-old bases. Mine them for *dataset and merge recipes*, not as the production brain. (CORRELATIONAL)
6. **MoE serving complexity.** Big-MoE quality-per-active-parameter is real, but serving (vLLM/SGLang, expert routing, memory planning) is an ops project. For a two-person team, dense 27–35B beats flashy MoE until there is a dedicated infra hire. (HYPOTHESIS — team-specific)
7. **Kimi synthetic-data clause.** If any pipeline stage uses K2.6 output as training data, the derivative cannot claim K2.6's license. Keep K2-family strictly at arm's length from the corpus. (BUILT)
8. **Single-source models.** Qwen3.6 and several Part-1 entries trace to one tracker/one hardware site. Verify on Hugging Face before procurement. (flagged inline)
9. **The real bottleneck is not on this list.** It is the corpus. Compute is solved ($250), licenses are solved (Apache 2.0), the edit toolkit is solved (Unsloth + mergekit). The etiquette/de-escalation/twelve-steps dataset and the jailbreaker CI suites are the critical path — consistent with the lock-down order already set: two-behavior challenge → corpus population → etiquette sub-domain → synthetic cohort.

---

## APPENDIX — SOURCE REGISTER (accessed 2026-09-25)

| # | Source | Used for | Authority |
|---|---|---|---|
| S1 | github.com/xigh/open-weight-models (living tracker, Apr 2026) | Tier table, license tiers, alternative architectures | S |
| S2 | codetocloud.io open-source LLM comparison (May 2026) | License/context/commercial matrix, Apple Silicon column | B |
| S3 | thelec.net — Gemma 4 Apache 2.0 launch (Apr 2026) + dev.to/mindstudio/viteseo Gemma 4 license analyses (Apr 2026) | Gemma 4 license facts, size table | B |
| S4 | io.net fine-tuning cost FAQ (2026) + Spheron fine-tune cost guide (Mar 2026) + guptadeepak platform pricing roundup (Sep 2026, prices checked 09-18) | All training-cost anchors | C/NA — cross-checked across three |
| S5 | willitrunai.com M1 Max 64GB fit sheet (Aug 2026) + localaimaster Apple Silicon benchmarks (2026) + dralart M1 Max optimization (Apr 2026) | Laptop fit envelope, tok/s figures | B/NA |
| S6 | clore.ai mergekit docs (Aug 2026) + zylos.ai merging research (Jan 2026) + spheron SLERP/TIES/DARE explainer (Sep 2026) | Merge methods | B/C |
| S7 | orcarouter abliteration explainer (Aug 2026) + atomic.chat abliteration guide (Aug 2026) + privatellm Heretic comparison (Apr 2026) + abliteration.ai (Jun 2026) + featherless cybersecurity note (Sep 2026) | Refusal-surgery mechanics, quality tradeoffs | B/NA |
| S8 | handyai.substack Kimi K2.6 drop (Apr 2026) + kili-technology K2.6 analysis (May 2026) + frankx K2.6 FAQ (Jun 2026) + wan27 Kimi K3 tracker (Jul 2026) | Kimi family specs, Modified MIT terms, synthetic-data clause | A/B |
| S9 | noviai RP model ranking (2025) | Legacy RP canon | B |
| S10 | turingpost 10 open MLLMs (Sep 2026) | Vision-model shortlist | NA |
| S11 | enterpriseDNA OpenRouter board explainer (Sep 24, 2026) + openrouter.ai/rankings | Usage-vs-quality distinction | B |
| S12 | qwe.edu.pl GGUF deployment guide (Jul 2026) + tech-insider GGUF tutorial (Sep 2026) + arXiv 2601.14277 llama.cpp quantization study | Quantization, llama-server | B/S |

*Conflicts registered: none material. The codetocloud table's "Gemma 3 ToU / Gemma 4 Community" cells are stale relative to the April 2026 Gemma 4 Apache 2.0 launch; S1/S3 corroborate the launch. Where a blog and a tracker disagreed on a benchmark number, the more conservative figure was kept.*
