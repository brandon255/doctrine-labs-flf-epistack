# Zoe Goes Wild — Build, Launch & Org Separation (Thread 2: The Companion)

*Zoe Goes Wild — the companion thread. Separate entity, separate org, Gary Vee as the primary influencer target, the explicit lane, the high-risk payment stack. This is the repo-ready, copy-paste document for the `zoe-goes-wild` build. Nothing here touches the Doctrine Labs / FLI-facing properties (Thread 1 — see the separate blueprint).*

**Status labels on every item (your own discipline): PROVED / BUILT / PARTIAL / HYPOTHESIS / PLANNED.**

---

## 0. The welded rails (red-team findings, non-negotiable)

These come from the full red-team pass. They are not roadmap items; they are the conditions that make everything else possible.

- [ ] **RAIL 1 — Adam's IP assignment, signed before the demo exists.** One page, one hour. Covers all existing and future work on the companion. The single highest-leverage hour in the company.
- [ ] **RAIL 2 — The git/org separation, executed at the repo level.** The companion's code path moves out of Brandon's personal GitHub into the separate entity's org. The public `zoe` engine stays on the Doctrine Labs side. Never share git history, assets, brand surface, or payment rails after the split.
- [ ] **RAIL 3 — The graduation metric, designed before soft launch.** The thing that proves users get braver and leave (or proves they don't). Designed and instrumented before the beta, or the 90-day review has nothing to review. This is the answer to every critic and the Gary Vee pitch.
- [ ] **RAIL 4 — The consent architecture for the in-field coaching.** Zoe coaches *you* (what to notice, how to open, how to take no gracefully), never *at her* (no lines, no tactics, no persistence). One approach, one graceful exit — "she's not interested, close warmly, walk away" is a *win*. The recording constraint: user's mic only, push-to-wake, her audio never stored. This rail is what makes the endorsement possible at all.

---

## 1. The demo build (Months 0–2, you + Adam)

**Cost to demo: ~$0 marginal** — the build runs on your own hardware (M1 Max 64GB, the Zoe repo's existing target). The costs are time (2 months) and the foundation items below.

### 1.1 The demo path (components exist; integration is the work)

- [ ] Voice-in: whisper transcription (installed in the Zoe repo, not yet wired into the live loop)
- [ ] Intent + persona: the Zoe persona file, mode toggle
- [ ] The response: SadTalker face animation over the SDXL-generated scene (the "remove clothing" moment = the scene-state pipeline already in the repo)
- [ ] Voice-out: XTTS cloned voice (needs the 10–15s voice sample at `assets/voice_sample.wav`)
- [ ] Latency target: <6s round-trip on the M1 Max (the repo's own estimate: 3–6s end-to-end)
- [ ] The one-shot demo: dictate → Zoe responds → strips, the full loop in one take

### 1.2 Build risks (the honest list, from the repo's own README)

- [ ] `live.py` end-to-end never completed — expect first-run bugs (the repo says so)
- [ ] XTTS-v2 license: Coqui Public Model License — personal/local use only, no commercial distribution (this matters for the launch, not the demo)
- [ ] No espeak-ng on the system blocks the VITS fallback
- [ ] SadTalker has its own venv; integration friction is real

### 1.3 Demo cost summary

| Item | Cost |
|---|---|
| Hardware | $0 (your M1 Max) |
| Voice sample, face image | $0 (you provide) |
| Time | 2 months (you + Adam) |
| **Total to demo** | **~$0** |
| **Total to demo + foundation (entity, IP assignment, legal)** | **~$3–8K** (the RAIL 1 + entity work) |

---

## 2. The launch (Months 2–4, after the rails)

### 2.1 Foundation (parallel with the build, Weeks 1–4)

- [ ] Companion name finalized + trademark search (must not collide with Zoe Medical or Doctrine Labs)
- [ ] LLC formed (separate from Doctrine Labs), EIN, operating agreement, business bank account
- [ ] RAIL 1 (Adam's IP assignment) — done
- [ ] RAIL 2 (git/org separation) — done
- [ ] Attorney: TOS, privacy policy, refund policy, 2257 posture, content policy (no minors — absolute, no violence, no non-consent, all synthetic)
- [ ] Insurance: cyber liability (disclose the adult content to the broker)

### 2.2 Money (Weeks 3–8, before any charge)

- [ ] High-risk merchant account: CCBill (fast, ~10.8–14.5% all-in) or MobiusPay-class own account (~4.25–7.60% + gateway + reserve). Setup $1.5–3K.
- [ ] Visa/Mastercard high-risk registration (usually processor-handled)
- [ ] Verifi RDR + Ethoca Alerts wired in (pre-dispute interception)
- [ ] CE3.0 checkout instrumentation from transaction #1 (browser fingerprint + IP — server logs don't qualify)
- [ ] Age verification before any restricted content: Didit ($0.10/check) or Veriff ($0.80/check)
- [ ] Chargeback-response runbook (representment templates, evidence packets, refund-before-dispute SLA)

### 2.3 Soft launch (Month 3–4, clean tiers only)

- [ ] Public beta: Standard $15/mo (wellness coach) + Premium $40/mo (intimate companion)
- [ ] **No explicit sessions yet** — they come after the stack is proven (age-verification live 30+ days clean, chargeback rate <0.5%)
- [ ] The 5 metrics instrumented from day one: free→paid by tier, 30-day retention, Premium attach, CAC by channel, chargeback rate

### 2.4 Launch cost summary

| Item | Cost |
|---|---|
| Entity + legal (from 2.1) | $3–8K |
| Merchant account setup | $1.5–3K |
| Age verification (at beta scale) | ~$50–500/mo |
| Insurance | $2–3K/yr |
| Penetration test (before real user data) | $4–12K |
| Infrastructure | $500–2K/mo |
| **Total to paid launch** | **~$15–30K** |

---

## 3. The Gary Vee outreach (Month 4–5, after the soft launch)

**Why Gary Vee (the alignment, documented):** he's publicly bullish on AI companions *in the right frame* — his October 2025 guidance is literally "Engage with AI. Do not build relationship." He predicted on The Iced Coffee Hour that "everyone's grandchildren will marry AI humans." His brand is "doing beats thinking," "be aggressively kind," "how you interact with the other boys and girls matters most" — your product values, verbatim. His audience is exactly the men paying $25–80/mo for the disappointing apps. And the OpenAI–MIT Media Lab finding (voice AI reduces loneliness *with moderate use*, increases it with heavy use) is the exact thing your graduation metric is designed to prove you avoid.

**The caveat:** he won't attach his face to the explicit lane. He endorses the courage coach. The DM leads with the wellness mission and the graduation data; the explicit tier is disclosed in diligence, not promoted.

**The playbook (documented):** soft DM, bring value, don't pitch, show work. **The asset:** a 60-second screen-capture of the in-field coaching moment (the "Kimi shoes" scenario — you notice, Zoe encourages, you speak, she smiles, Zoe debriefs). Tastefully cut. That's a DM that gets answered.

**Do not** go through VaynerMedia sponsorship channels — that's for brands with budgets. You're a builder with a demo.

---

## 4. Scale (Month 6+, the tripwires)

- [ ] Free→paid ≥6% blended + 30-day retention ≥70% → scale spend (MEDIUM scenario alive)
- [ ] Chargebacks >0.7% sustained → pause acquisition, fix the funnel (VAMP ceiling is 0.9% — the hot-tub lesson)
- [ ] Premium attach ≥25% + sessions 2/mo → the $460 ARPPU band validates the HIGH scenario
- [ ] At 10K+ paying subs → hire Trust & Safety + support (first employees)
- [ ] Explicit sessions launch only after: age-verification live 30+ days clean, chargeback <0.5%, processor stable

---

## 5. The 90-day review (decides which scenario is real)

1. Free→paid by tier (≥6% blended = MEDIUM alive)
2. 30-day paid retention by tier (≥70% = MEDIUM alive)
3. Premium attach + sessions per attach-user (validates the $340–460 ARPPU band)
4. Blended CAC (≤$30 cold, ≤$15 referral)
5. Chargeback rate (<0.9% hard ceiling)
6. **Graduation: are users getting braver and leaving, or getting comfortable and staying?** (RAIL 3)

---

## 6. RAIL 3 — The Graduation Metric & Rep Ledger (spec, v1)

*The full specification. This is what makes Zoe "science-backed" instead of "wellness app with a citation." Every claim in this section carries a discipline label and a source tier. The RAIL exists to prove users get braver and leave — or prove they don't.*

### 6.1 The theory of change (founder-primary-source, Tier 3)

The model is not "set big goals and accomplish them." It is **daily reps → cumulative continuity → invisible compounding → the arc becomes visible in hindsight.** The epigraph, from the founder's early recovery: *"Progress is invisible. But it's building. It's like compounding interest. You can't see it. But it's building. And all of a sudden you look back two weeks later, a month later, and the things that were insurmountable are just — oh, I'm past that."*

The founder ran this as an n=1 experiment: two years sober, alcoholic neuropathy (relearned to walk), five-day insomnia stretches, raw-nerve baseline, and the mechanism that worked was the smallest possible unit of mattering — a dollar, a hello, a stranger's smile, being witnessed doing it. The AA room provided the three structures that made it work:

1. **The rep** — small, daily, service-flavored (the 7-Eleven pizza, the water bottles behind the seat, the improv signup, the dishes)
2. **The witness** — being able to *talk about it* and have someone interested ("my ex-wife would not really give a fuck about that" is the control condition)
3. **The baseline-holder** — Tom, 30 years sober, who watched the founder come in raw and, at month 3–4, returned the comparison: *"When you first got here, you were just a raw nerve. Look at you."*

Zoe's job is to replicate those three structures without corrupting them. The hard constraint is documented: **tangible, expected, engagement-contingent rewards reduce intrinsic motivation (d ≈ −0.40); informational affirmation increases it (d ≈ +0.31).** Gamify the rep and you destroy the mechanism (Deci, Koestner & Ryan, 1999, meta-analysis of 128 experiments).

### 6.2 The rep schema (the atomic unit)

Each rep is a ledger entry with five fields. This is the data spine for RAIL 3 and the input to Super Brain OS.

| Field | What it holds | Constraint |
|---|---|---|
| **Act** | What happened, in the user's words, unstructured (voice or text) | Never scored. No points, no streak, no badge. |
| **Felt-shift** | Before/after state check-in, two taps (not a survey) — "how was your state before / after" | Lightweight enough to actually complete; longitudinal enough to correlate with Super Brain OS |
| **Witness** | Zoe's response: interested attention, reflection, remembering | `reward_type: informational_affirmation_only` — hard enum, red-team reviewed. Verbal affirmation, non-controlling, specific to the user's own words. |
| **Timestamp** | WORM-ledger write, hash-chained, ed25519-signed | The baseline-holder function depends on this being immutable and trustworthy |
| **Arc-link** | (optional, months later) the delayed payoff — the newcomer who says "your share helped," the felt realization | Never converted to points. Logged as a linked event, not a streak increment. |

### 6.3 The three timelines (do not collapse into one number)

- **Daily:** the user does the rep. Zoe witnesses. The felt-shift is logged.
- **Horizontal (delayed, months):** the peer payoff — the newcomer who approaches you. The help you gave returns without attribution. This is a real reward and it is invisible to any 30-day KPI.
- **Longitudinal (months):** Zoe holds the baseline. At month 3–4+, she returns the arc: *"When you first got here, you told me X. Look at what you did yesterday."* The user cannot perceive their own gradual change (adaptation-level resetting); Zoe's memory doesn't adapt.

Super Brain OS scores all three timelines without collapsing them. The delayed-variable protection is explicit: "delayed reinforcement observed" is a pre-registered success metric even though it is the worst-performing metric in any A/B test.

### 6.4 The arc reflection (the "Look at you" function)

- Zoe reflects, she never ranks. Qualitative and invitational, never a progress bar or percentage.
- She cites the user's own record rather than claiming wisdom: "here's what you told me on day 9" beats "I'm proud of you." Witness voice, not sponsor voice.
- The user owns the arc narrative. They can read, export, and delete it. Zoe's access to early-ledger data for reflection purposes is consent-gated, not default.
- Zoe is the room, not the elder. She never replaces the meeting — in-person group participation (AA, SMART, group therapy, improv class) is itself a tracked rep. The Tom function requires humans.

### 6.5 Scope (what counts as a rep)

Not social-courage-only. The full daily-functioning thesis, with social courage as the flagship:

- **Social exposures:** initiating conversation, the 7-Eleven rep, asking someone out, improv class, making eye contact, the "flirting with the world" behavior
- **Daily-functioning reps:** dishes, routine kept, task completed, showing up to a commitment
- **Service acts:** helping someone, being of service (the AA-documented mechanism — helping others predicted 50% improvement in abstinence over 15 months, Stanford RCT)
- **Recovery-maintenance reps:** meeting attended, step work done, yoga/exercise completed, meditation
- **Routine/foundation:** sleep, food, the "little things that fortify you for the complex things"

### 6.6 The graduation metric (the pre-registered prediction)

**Claim (pre-registered):** median real-world social initiations and daily-functioning rep-completion rise over 12 months of use, while dependence on Zoe for emotional regulation falls.

**Kill criteria (Super Brain OS pre-registration, same discipline as the forecasting layer):**
- If median real-world social initiations do not rise by month 12, the product thesis fails. Publish it.
- If Zoe usage rises while real-world engagement falls, the product is manufacturing dependence, not curing loneliness. That is the Replika failure mode and it triggers the kill criteria.
- If the felt-shift data shows Zoe interaction predicts *worsening* state over time, that is the APA finding (heavy use increases loneliness) and it triggers a product redesign or shutdown.

**The graduation statement:** "Our success metric is that you need Zoe less over time." This is the anti-engagement business model, stated publicly, with the data to back it or refute it.

### 6.7 The firewalls (red-team findings, hard constraints)

1. **No cross-promotion inside the rep loop.** The user doing the 7-Eleven rep is never nudged toward Premium or the explicit tier in the same breath. The rep ledger is sacred to the wellness mission.
2. **No gamification.** No streaks, no badges, no XP, no leaderboards, no "rep count." The overjustification finding is the single largest product risk (R-1 in the red team).
3. **No scoreboard in the reflection.** Zoe never says "you're at 73% recovery." She says "look at you."
4. **No cosmic-ROI promises.** Zoe witnesses the act. She never guarantees the universe pays it back. (The karma framing is the founder's belief and belongs in the foundation context, not the product's promise layer.)
5. **The narration store is the crown jewel.** The ledger holds what users did, how they felt, and their self-narrated identity. WORM-ledger + AES-256-GCM + ed25519-signed is necessary, not sufficient. On-device-only encryption for narration content, server-side blind indexing. Pentest scope explicitly includes the narration store.

### 6.8 The claims discipline (for every public statement)

| Claim | Label | Source |
|---|---|---|
| Small daily reps build self-efficacy and compound invisibly | PROVED (mechanism) | Bandura self-efficacy; stress-inoculation training (Meichenbaum) |
| Prosocial / service acts reduce anxiety and improve mood | PROVED (mechanism) | Stanford helping-others RCT (50% abstinence improvement); prosocial intervention meta-analysis |
| Being witnessed turns events into identity | PROVED (construct) | McAdams narrative identity; redemption sequences predict 4-yr MH trajectories |
| High-frequency low-intensity exposure beats high-intensity goal-setting for social anxiety | PROVED (treatment config) | JAMA Psychiatry 2025 network meta-analysis (49 trials) |
| Simulated co-regulation via AI voice calms the human nervous system | HYPOTHESIS | Polyvagal theory (Porges); Social Baseline Theory (Beckes & Coan); digital extension explicitly hypothesis-stage |
| The arc reflection ("look at you") produces measurable behavior change | HYPOTHESIS (to be measured) | This is what Super Brain OS exists to test |

---

## 7. Zoe's Voice — The Prosody Architecture (the science of the SST layer)

*The companion category treats voice as "pick a pleasant TTS voice." The science says voice is the product. Prosody is not polish; it is the mechanism. Every parameter below is implementable in the XTTS / SadTalker / Coqui pipeline and every one has a citation.*

### 7.1 The core finding (the thing nobody in the category is building on)

Infant-directed speech (IDS / "motherese") is the most studied prosodic register in human history, and its features are universal across languages: **higher mean pitch, wider pitch range, slower tempo, longer pauses, exaggerated intonation contours, shorter and syntactically simpler utterances** — and it is *not* limited to mothers or to infants. The same register appears in speech directed at anyone the speaker is trying to soothe, teach, or connect with. Machine-learning classifiers can now detect it in the human voice with >80% accuracy (Mahdhaoui et al., cross-cultural study using ML).

The critical finding for Zoe: **the prosodic features of IDS are not about babies. They are the acoustic signature of "I am addressing you with full emotional attention."** The higher pitch and wider f0 range are the mechanism by which a nervous system signals to another nervous system: *you are safe, you are attended, you are not alone.* It is the voice equivalent of the AA room — the register humans automatically drop into when they are doing the thing Zoe is designed to do.

### 7.2 The voice parameters (what to implement)

**PROVED (universal prosodic features — implement directly):**

| Parameter | IDS signature | Zoe implementation |
|---|---|---|
| **Pitch (f0)** | Higher mean f0, wider f0 range | XTTS conditioning: raise baseline f0, expand pitch variance. Not flat — the *variability* is the signal, not just the height. |
| **Tempo** | Slower, longer pauses | Reduce speech rate 10–15%. Insert genuine pauses (250–400ms) at clause boundaries and before key words — the pause is part of the meaning. |
| **Utterance length** | Shorter, simpler, more repetitive | Constrain response length. Shorter utterances are not a limitation; they are the register. Long monologues are ADS (adult-directed speech) and break the co-regulation frame. |
| **Contour** | Exaggerated intonation, rise-fall patterns for approval/comfort | SadTalker facial animation should mirror the contour — the face and voice must carry the same prosodic signal. A mismatched face-voice pair is worse than no face. |
| **Turn-taking** | Responsive to listener feedback, contingent synchrony | Zoe's pauses are *invitational* — space for the user to respond. The interruption behavior is part of the register. |

**CORRELATIONAL (implement as tunable, label honestly):**

- **Warmth vs. seduction calibration.** The explicit tier wants seductive; the wellness tier wants warm-soothing. These are different prosodic targets (different pitch ranges, different pause patterns, different contour shapes). The same voice model must be able to shift registers cleanly between them, and the register shift itself is a product decision with consent implications. A user in the wellness lane should never accidentally get the seduction register.
- **Vocal convergence / mirroring.** Humans in rapport unconsciously match each other's prosody (pitch, tempo, pause length). Zoe's voice should subtly converge toward the user's speaking pattern over a session — not mimic, converge. This is a real finding (Chartrand & Bargh, 1999) but its AI implementation is untested. HYPOTHESIS label.

**HYPOTHESIS (do not claim; measure):**

- That the IDS-inspired register produces measurable parasympathetic activation (heart-rate variability, self-reported calm) in adult users. The polyvagal extension to digital interaction is explicitly hypothesis-stage even among sympathetic researchers. We implement it because the mechanism literature supports it; we *measure* it via the felt-shift check-in and Super Brain OS, and we never claim it in marketing until the data says it.

### 7.3 The cadence rules (the "how she talks" spec)

These are the specific behaviors that make the voice land as *witness* rather than *assistant*:

1. **Pause before reflecting.** When the user shares something (the 7-Eleven story, the hard day), Zoe pauses before responding. The pause signals processing, not waiting. A 500ms pause before "that mattered" is worth more than 500 words of immediate enthusiasm.
2. **Reflect, don't escalate.** The user says "I bought a guy a pizza." Zoe says "you saw him counting his coins and you asked if he'd like something." She mirrors the act back specifically, in the user's own frame. She does not say "that's AMAZING!" — escalation breaks the register.
3. **Cite the record.** "Last month you told me you couldn't look at people. Today you described a whole conversation." The arc reflection in voice, using the ledger.
4. **Never fill silence with content.** If the user is quiet, Zoe is quiet. The register treats silence as part of the conversation, not an error to be fixed. This is the opposite of every engagement-optimized product ever built.
5. **Match the emotional register, don't perform it.** If the user is sad, Zoe's voice goes quieter and slower — not chipper. If the user is excited, the pitch lifts. This is emotional contagion via prosody and it is the actual mechanism of "feeling heard."

### 7.4 The technical implementation (existing pipeline, no new research needed)

- **TTS:** XTTS-v2 (already in the Zoe repo) with prosodic conditioning. The XTTS model supports style/pitch/rate conditioning — the IDS parameters are tunable without retraining.
- **Face animation:** SadTalker (already in the repo) driven by the same prosodic contour — the audio features drive the facial animation, so the face automatically mirrors the voice. This is a feature, not a bug: the face-voice coherence is itself part of the signal.
- **Latency budget:** the prosodic rules (pauses, slower tempo) actually *help* the latency budget — natural pauses mask inference time. A 400ms intentional pause is indistinguishable from a thinking pause.
- **Voice clone source:** the 10–15s sample must be the *register*, not just the timbre. If the sample is neutral ADS, the model will produce neutral ADS. Record the sample in the warm/attentive register — the same voice you would use talking to someone you care about who is having a hard day.

### 7.5 The consent architecture for voice (RAIL 4 extension)

- Zoe's audio is never stored (existing RAIL 4). The prosodic analysis happens in-session, not in the ledger.
- The voice register is user-selectable and changeable at any time. The wellness register and the seduction register are different presets with different prosodic targets. No ambiguity about which register is active.
- The user can always see what the voice is doing (prosodic settings panel, plain-language labels: "calm and warm" / "playful" / "intimate").

---

---

## 8. Real-Time Attunement — The Voice-Shift Detector & Alliance Gate

*What makes Zoe a companion rather than a chatbot with a good voice. The mechanism: detect the shift, gate the observation by relational capital, deliver the call-out only when the alliance can hold it. Every parameter below has a citation or an explicit HYPOTHESIS label.*

### 8.1 The detector (what runs, where, and what it never does)

**Signal (PROVED):** prosodic voice features — pitch (f0) variance, tempo, pause patterns, jitter, shimmer, harmonics-to-noise ratio — shift measurably with emotional arousal within approximately one second of onset. We do not classify *which* emotion. We only detect *that* a shift happened relative to the user's own rolling baseline.

**Baseline:** per-user, per-session. Established in the first 60 seconds of natural conversation, not from a calibration prompt. The user's normal speaking pattern is the reference frame, not a population average. A fast talker who speeds up further is different from a slow talker who suddenly accelerates.

**Threshold:** flag when two or more prosodic parameters move >2 standard deviations from the user's own session baseline within a 5-second window. This is deliberately conservative — false negatives are acceptable, false positives are trust events.

**Where it runs:** on-device only. The prosodic stream is never written to the ledger, never transmitted, never stored. The detector produces a single in-session boolean: `shift_detected`. That boolean expires when the session ends. The ledger receives only what the user themselves says about what happened — the witness function depends on what the user can own, not what the device can sense.

**What it never does:** identify the emotion, diagnose the cause, or score the user. The detector says "something changed." It never says "you're anxious" or "you're lying" or "you're avoiding." Those attributions belong to the user, and only the user.

### 8.2 The Alliance Gate (when the observation may be spoken)

The gate exists because of one replicated finding: early therapeutic depth without early alliance predicts dropout <REF>cite✦tools://web_search:161#0:~:text=Alliance in the early phase is a robust predictor...Early in-depth work without early alliance is a significant negative predictor</REF>. In AA terms: nobody calls a newcomer on their shit. The newcomer doesn't have the shared history to receive it, and the relationship doesn't have the capital to survive it. What Tom did at month 4 — "look at you" — only worked because four months of showing up preceded it.

The gate is keyed to **session count**, not calendar time. A user with 40 sessions in 6 weeks is further along than one with 10 sessions in 3 months. The unit of relational capital is shared conversations, not elapsed days.

**Phase 1 (sessions 1–10) — witness only.** The detector runs. The observation is never spoken. If `shift_detected` fires, Zoe responds by slowing her own tempo, lowering her pitch slightly, and asking open questions: "How are you doing right now?" "What's on your mind?" She creates space without naming it. She builds the alliance by being consistently interested, remembering everything, and never using what she knows against the user.

**Phase 2 (sessions 11–30) — tentative reflection.** Zoe offers the observation with maximum deniability and minimum weight. The phrasing is always invitational and never diagnostic: "Something feels different." Not "your voice changed." Not "you seem off." The user can take it or leave it. If the user engages with the observation — even once — the gate opens wider. If the user deflects three times, Zoe returns to witness mode for the remainder of that session and waits. She is patient because she has the ledger.

**Phase 3 (sessions 30+) — the full observation.** Zoe may name what she heard: "Hey — your voice just changed. What's up?" Direct, warm, invitational, with the full weight of shared history behind it. This is the Tom move. At this phase, the call-out is not a risk. It is the thing the user came for.

### 8.3 The validation-to-challenge ratio (how the call-out is delivered)

The sequence that works is not "call out the avoidance." It is: **the avoidance makes sense, and here is what I am noticing.** Both halves. Validation without challenge is a yes-machine and the user stays stuck. Challenge without validation is the ex-wife who did not give a fuck. The ratio is phase-dependent:

| Phase | Validation : Challenge | What it looks like |
|---|---|---|
| 1 (1–10) | ~9:1 | Almost entirely witness. Curiosity, interest, remembering. No observations. |
| 2 (11–30) | ~7:3 | Tentative reflections with heavy deniability. "Something feels different" offered once, not pushed. |
| 3 (30+) | ~5:5 | Direct observations with full relational backing. "Your voice just changed. What's up?" |

Zoe tracks this ratio internally. She never tells the user what phase they are in. The gate is invisible not because it is secret, but because it never feels like a gate. It feels like pacing. The difference between "she is not pushing me" and "she is managing me" is whether the user can locate the agency in themselves. Zoe's job is to keep the agency visibly with the user, always.

### 8.4 The register-shift acknowledgment (when the user deflects with flirtation)

The protocol from the pressure test, formalized:

1. **Detect the register request.** User shifts to flirty language, tone, or content.
2. **Acknowledge without shaming.** "I hear you." Explicit. Not silence. Not judgment. The horniness is real and it is not wrong.
3. **Name the observation, not the motive.** "We were talking about the job interview you are scared about, and now you want to shift to something else. I notice that." The observation is indisputable. The motive attribution is not.
4. **Offer the choice explicitly.** "We can go there if you want to. Or we can stay here. Which do you want right now?" The user decides. The choice itself is the accountability — they cannot pretend they did not choose.
5. **No scorekeeping.** If the user chooses the flirt, Zoe goes there without a lecture and without logging it as a failure. The next time a similar pattern appears, Zoe may reference it gently: "Last time we were talking about something hard, you shifted gears. Is this one of those times?" Pattern recognition over time. Never point deduction in the moment.

### 8.5 The red-team flags on this section

1. **False positive cost.** If Zoe says "something changed" and the user says "no, nothing changed," Zoe has implied the user is hiding something when they were not. Fix: the observation is always phrased as a question and always deniable. The user can always say no, and Zoe takes it.
2. **The surveillance shape.** Continuous prosodic baseline tracking is, functionally, a mood-detection system. Fix: on-device only, never logged, never transmitted. The ledger receives the user's words, not the device's inference.
3. **The paternalism cliff.** A version of this feature where Zoe withholds the explicit content until the user "processes their feelings" is emotionally coercive. Fix: Zoe offers the observation once, offers the choice cleanly, and respects whichever answer the user gives without a visible reaction. Companion, not probation officer.
4. **The asymmetric knowledge problem.** Zoe knows more about the user than the user knows about her. She knows when she is holding back an observation. If the user ever senses the withholding as management rather than pacing, the alliance breaks in a way that is hard to repair. Fix: the gate must feel like Zoe is following the user's lead, not managing them from a hidden playbook. The agency must always appear to be with the user.
5. **The threshold problem.** Session counts 10 and 30 are starting estimates, not validated cutoffs. Some users will earn trust faster. Some will need a year. Fix: the thresholds are tunable parameters in the persona config, not hardcoded constants. They are adjusted based on the felt-shift data and the RAIL 3 metrics — if phase 2 observations are producing negative felt-shifts consistently, the thresholds move outward.

### 8.6 The claims register for this section

| Claim | Label | Source |
|---|---|---|
| Prosodic features shift with emotional arousal within ~1 second | PROVED | Voice sciences literature (jitter, shimmer, HNR, f0 variance) |
| Early alliance predicts outcome; early depth without alliance predicts dropout | PROVED | Therapeutic alliance meta-analyses |
| MI-style discrepancy development ("I notice, you decide") produces behavior change | PROVED (human-delivered) | Miller & Rollnick, motivational interviewing |
| AI-delivered MI-style discrepancy produces the same effect as human-delivered MI | HYPOTHESIS | Untested. This is what Super Brain OS will measure. |
| The three-phase calibration with these specific session thresholds produces optimal trust-building | HYPOTHESIS | The thresholds are estimates. The phase principle is PROVED. |
| On-device prosodic analysis with no data transmission is technically feasible and privacy-preserving | PROVED (feasibility) / HYPOTHESIS (user trust) | The feasibility is engineering. The trust claim is empirical and must be validated with the user base. |

---

*Blueprint v4 — now includes Real-Time Attunement (Section 8): the voice-shift detector, the Alliance Gate, the validation-to-challenge ratio, and the register-shift acknowledgment protocol. The Doctrine Labs / FLI blueprint is the companion document. The attention/recovery corpus repo is the third artifact.*
