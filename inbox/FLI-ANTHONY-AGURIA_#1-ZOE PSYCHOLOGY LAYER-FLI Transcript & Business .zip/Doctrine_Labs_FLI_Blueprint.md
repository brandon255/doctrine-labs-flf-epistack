# Doctrine Labs — FLI-Aligned Blueprint (Thread 1: Safety, Epistemics, Tool AI)

*Doctrine Labs — the mission-facing thread. This is the FLI/safety/epistemics side: Core OS, Career OS, Zoe Medical, the FLF submission trail. Scott Galloway stays on this thread as a LATER mission-aligned target (the social-skills crisis), sequenced after the wellness coach is proven. The companion (Zoe Goes Wild) is Thread 2 — separate entity, separate repo, Gary Vee, separate blueprint. Nothing in Thread 2 touches these properties.*

---

## The thread separation (the red-team finding, executed)

| | Thread 1 — Doctrine Labs | Thread 2 — Zoe Goes Wild |
|---|---|---|
| Products | Core OS (Fieldcraft), Career OS, Zoe Medical, FLF/AISI toolkits | Zoe companion (wellness + intimate + explicit), MCP Commander paid |
| Entity | Doctrine Labs entity (clean) | Separate LLC (companion name) |
| GitHub | Separate org; `zoe` public engine stays here | Separate org; `zoe-goes-wild` |
| Influencer | Scott Galloway (later, wellness-proven) | Gary Vee (primary, first) |
| Payment story | Standard SaaS | High-risk merchant account |
| FLI/FLF posture | Public, clean, the submission trail | Never referenced |

**The welded rail: the two threads never share git history, brand surface, payment rails, or marketing after the separation is executed.** This is the motionforge R9 doctrine rule applied at the company level.

## The FLI-facing assets (current, verifiable)

- Core OS / Fieldcraft: deterministic safety at the read/write boundary, 174+ tests, red-team harness gating CI, the Five Gates (Gate 5 = Aguirre's tool-vs-replacement framing).
- FLF Epistack: three-level lineage engine, 210 tests, MIT, submitted to the Future of Life Foundation (Aug 2026).
- AISI Lineage + Eval-Contamination toolkits: 306 tests total, applied to FLI's own AI Safety Index.
- Zoe Medical: the Utah simulator track (separate from the companion), the instructor console, the Bizarro switch with welded safety rails.

## The Galloway outreach (deferred, sequenced)

- **When:** after the wellness coach has 90-day graduation data (the proof that users get braver and leave). Not before — his AiLONE essay makes him the *hardest* mission-endorser until the data exists.
- **The frame:** "We're building the social-skills training you say is missing — engineered to graduate men toward real-world confidence, local-first, priced below the incumbents. Here's the data."
- **The thing he never sees:** the explicit lane, the strip command, the companion's payment stack. Those live in Thread 2.

## The FLI thread's next 90 days

1. Keep the FLF/FLI submission trail warm (the toolkits are public, MIT, and the methodology is the conversation).
2. Instrument the Core OS / Career OS usage the same way the companion will instrument graduation — the "strengthen the human" claim needs the same measurable proof on the clean side.
3. Publish the doctrine (the Five Gates, the claims-discipline labels) — the public artifact the safety community and Galloway's team can both point at.

*Blueprint v2 — separated. The Zoe Goes Wild blueprint is the companion document.*
