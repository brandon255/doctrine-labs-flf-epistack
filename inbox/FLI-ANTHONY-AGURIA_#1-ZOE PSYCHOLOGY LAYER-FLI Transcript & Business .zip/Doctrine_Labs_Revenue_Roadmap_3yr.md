# Doctrine Labs — Three-Year Revenue Roadmap (Final, Rev 3.1)

*Prepared for Brandon Flores, Doctrine Labs — September 24, 2026. Rev 3 incorporates: companion-market pricing research (Rev 2), payment/chargeback stack pricing, build-cost reality (2-person team, 60-day demo timeline), and demo-to-launch sequencing. Companion deep-research report in this folder.*

---

## 1. The timeline reality

- **Month 0–2 (Oct–Nov 2026):** Zoe build to working demo — dictate, she responds, strips, voice + SadTalker-animated + SDXL scene pipeline (all components already exist in the `zoe` repo; integration is the work).
- **Month 2–3 (Nov–Dec 2026):** Entity, legal, payments, age-verification, insurance, pentest — the compliance floor.
- **Month 3–4 (Q1 2027):** Public beta (clean tiers first: Standard $15/mo + Premium $40/mo). Conversion/retention instrumentation from day one.
- **Month 4–6 (Q2 2027):** Explicit sessions ($100/5-min) added once the high-risk processor + age-verification stack is proven. Paid launch complete.
- **Y1 2027 = ~2 quarters of paid operation** (not 4). Y2–Y3 full years.

## 2. Build cost (you + Adam, to demo and to launch)

| Item | To Demo (M2) | To Paid Launch (M4) |
|---|---|---|
| Entity + legal (LLC, EIN, registered agent, attorney TOS/privacy/2257, **IP assignment Brandon↔Adam**) | $3,000–8,000 | (included) |
| High-risk merchant account setup (CCBill fast / MobiusPay-class own) | $1,500–3,000 | (included) |
| Age verification (Didit $0.10/check or Veriff $0.80/check + min) | ~$100 | $50–500/mo |
| Insurance (cyber liability, adult-adjacent premium) | — | $2,000–3,000/yr |
| Penetration test (external, before real user data) | — | $4,000–12,000 |
| Compliance tooling (CE3.0 instrumentation, Verifi/Ethoca, audit logging) | $1,000–3,000 | (included) |
| Infrastructure (Cloudflare-class web+streaming) | ~$200/mo | $500–2,000/mo |
| Contingency (~12%) | ~$1,000 | ~$2,000 |
| **Total** | **~$8,000–15,000** | **~$15,000–30,000** |

## 3. Three scenarios, three years (2027–2029)

Companion model: Standard $15/mo ($180/yr) / Premium $40/mo ($480/yr) / Sessions $100 per 5-min explicit (attach 15–25% of Premium, 1.5–2/mo). Blended ARPPU: LOW $240 / MEDIUM $340 / HIGH $460. Conversion 8–12% industry band; churn 8–12%/mo netted in subscriber counts. Payment stack cost ~7–9% of revenue (own high-risk account + gateway + interception + age verification + reserve drag); card-to-crypto settlement is excluded (Stripe/Bridge and Visa/MC treat AI-generated adult as higher-risk than filmed — same content rules apply, no advantage).

### LOW — $0.44M / $1.15M / $2.47M
Companion 1,500→4,000→9,000 paying subs; medical licenses late; services carry early.

### MEDIUM — $1.67M / $5.46M / $13.5M
Companion 4,000→14,000→36,000 paying subs; 2→6→14 medical site licenses @ ~$18K; tools and services plateau.

### HIGH — $4.34M / $12.6M / $28.3M
Companion 8,000→24,000→55,000 paying subs; Utah beachhead converts early; category-quality thesis fully validated.

## 4. The $20M-in-5-years verdict — FINAL

**Reachable in the MEDIUM scenario, with conditions.** Y5 extrapolation with deliberate deceleration: HIGH ~$62M, MEDIUM ~$27M, LOW ~$4.7M by 2031. The $20M target sits at the MEDIUM outcome — achievable if (1) free→paid conversion lands at the 8–12% band on a working web funnel, (2) churn holds ≤12%/month, (3) the explicit tier ships on a stable high-risk stack without a processing interruption. Miss any of the three and you land in LOW. This is a meaningful upgrade from Rev 1 ("not realistic") driven entirely by corrected category data (real ARPPU $25–80/mo for worse products; 8–20% conversion; LTV:CAC 10–40:1).

## 5. The 90-day instrumentation (decides which scenario is real)

1. Free→paid by tier (≥6% blended keeps MEDIUM alive)
2. 30-day paid retention by tier (≥70% keeps MEDIUM alive)
3. Premium attach + sessions per attach-user (validates $340–460 ARPPU band)
4. Blended CAC (≤$30, per category LTV:CAC)
5. Chargeback rate (must stay <0.9% — VAMP threshold; the hot-tub lesson)

## 6. WITHOUT vs. WITH Gary Vee endorsement (added Rev 3.1)

The endorsement changes **acquisition economics only** — no new revenue line, no new product. It compresses the time-to-trust curve that the whole web-only funnel depends on. Modeled here on the MEDIUM scenario; LOW and HIGH shift proportionally on the companion line only.

**Endorsement assumptions (labeled, not proven):**
- Referral wave: ~8,000–15,000 paying subs landed in Y1 via the playbook outreach (his audience is 45M followers / ~300M monthly impressions; even a fraction-of-a-fraction conversion at 12–15% on a warm landing funnel lands here — PROVEN math, HYPOTHESIS reach)
- Blended CAC drops to **$8–15** (organic/referral traffic replaces paid acquisition for the wave cohort)
- Better retention in wave cohort: trust-transferred users churn ~2 pts lower
- Companion line moves: 4,000→14,000→36,000 subs becomes **6,000→20,000→48,000**; medical, tools, services, grants unchanged

| Revenue ($M) | Y1 (2027) | Y2 (2028) | Y3 (2029) | Y4 (est.) | Y5 (2031) |
|---|---|---|---|---|---|
| **WITHOUT endorsement (MEDIUM)** | $1.67M | $5.46M | $13.5M | $19.6M | **$27.4M** |
| **WITH endorsement (MEDIUM)** | $2.51M | $7.90M | $17.8M | $25.8M | **$36.1M** |
| Delta (WITH − WITHOUT) | +$0.84M (+50%) | +$2.44M (+45%) | +$4.26M (+32%) | +$6.2M | +$8.6M |

![Revenue projection: WITHOUT vs. WITH Gary Vee endorsement (MEDIUM scenario)](doctrine_labs_report_assets/fig11_vee_compare.png)

**Reading the numbers:**
- The uplift is **front-loaded** (+50% Y1, +32% Y3) because the endorsement is a one-time wave, not a compounding growth mechanism. It buys you a bigger base earlier; the base compounds from there.
- **$20M-in-5-years verdict update:** WITHOUT Vee, the MEDIUM scenario still reaches $27.4M by 2031 — the goal stands on its own. WITH Vee, it reaches $36.1M and crosses $20M a full year earlier (Y4 instead of Y5). The endorsement converts the goal from *reachable with conditions* to *comfortable*.
- **What the endorsement does NOT fix:** churn replacement math, processing stability, or the three MEDIUM conditions in §4. It accelerates the top of the funnel; the bottom (retention, chargebacks, stack reliability) is unchanged. This is why RAIL 3 (graduation metric) and the payments stack matter more than the endorsement itself.
- **Fallback cost of pursuing it:** near zero. The playbook is soft-DM → bring value → documented work → 60-second demo asset. Worst case, no reply, and you're at the WITHOUT line — which already works.

## 7. Risks priced into every scenario

- Payment processing friction (high-risk fees, rolling reserve cash-lock, MATCH-list exposure if done casually)
- Web-only distribution (no app-store funnel; growth = content/community/referral)
- Churn replacement math (10%/mo means rebuilding the base constantly)
- Single-operator + one-partner execution across 28 repos and 5 products
- Explicit-tier policy risk (processor content rules tightening on AI-generated adult)

---

*Working model. Companion document: the end-to-end build blueprint (entity → payments → compliance → security → insurance → IP → customer ops → scale → outreach sequence) is maintained as the operations layer for the Zoe repos.*
