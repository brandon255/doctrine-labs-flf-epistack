# Epistack Integration — How the Corpus Feeds the FLF Lineage Engine

*The FLF Epistack (doctrine-labs-flf-epistack) is Doctrine Labs' three-level independence/lineage engine — 210 tests, MIT licensed, submitted to the Future of Life Foundation August 2026. This document defines how the attention/recovery corpus connects to it.*

---

## The three-level architecture (recap)

| Level | What it does | Corpus analogue |
|---|---|---|
| Level 1: Independence | Detects when claims are copied without attribution or when sources are misrepresented | Tier 1 vs. Tier 2 distinction; the adversary literature is the "before" picture |
| Level 2: Lineage | Traces where a claim came from, through what transformations, to what current form | The claim register (claim-register/claims.yaml) is the lineage record |
| Level 3: Contamination | Flags when a hypothesis from one domain has silently infected another domain's claims | The Thread 1 / Thread 2 separation rule; the two-thread firewall |

---

## How the corpus feeds each level

**Level 1 (Independence):** Every Tier 2 entry's DOI is checked against the claim register. If a claim in marketing or product materials cites a finding that is not in the corpus, the engine flags it as an unverified import. If a Tier 1 (adversary) finding is cited as evidence for a Tier 2 (counter-science) claim, the engine flags a category error. Example: citing Fogg's captology framework (T1-001) as evidence that "our focus ramp works" would be flagged — Fogg is the problem definition, not the solution evidence.

**Level 2 (Lineage):** The claim register is the corpus's Level 2 output. Every claim has a `used_in` field pointing to the artifact that makes it, and every artifact has a claims list pointing back. The bidirectional mapping means a change in the evidence base propagates automatically: if T2-R009 (Deci meta-analysis) were ever contradicted by a new meta-analysis, every claim that cites it (CR-007, and downstream the RAIL 3 spec's no-gamification constraint) would be flagged for review.

**Level 3 (Contamination):** The Thread 1 / Thread 2 separation is a Level 3 rule. A claim labeled HYPOTHESIS in Thread 2 (Zoe voice co-regulation) must never appear as PROVED in Thread 1 (FLI-facing materials). The engine checks cross-references between the two blueprints and flags any label inflation across the boundary.

---

## The 90-day review hook

Super Brain OS's quarterly review cycle (the one that decides which revenue scenario is real) now includes a corpus review step:

1. **Did any new peer-reviewed publication in the last quarter affect any active claim?** (Literature scan, quarterly.)
2. **Did any product data from the last quarter upgrade or downgrade any HYPOTHESIS claim?** (Super Brain OS felt-shift and RAIL 3 data.)
3. **Did any public statement in the last quarter use a claim not in the register?** (Marketing and PR audit.)

The output of step 2 is the corpus's growth mechanism: as Zoe generates felt-shift data, RAIL 3 metrics, and Super Brain OS forecasts, HYPOTHESIS claims get upgraded (or refuted) and the register updates. The corpus is not a static bibliography. It is the live record of what the company knows, what it believes, and what it is currently testing.

---

## What the corpus does NOT do

- It does not replace peer review. It organizes the peer-reviewed literature so the company's claims are checkable.
- It does not make HYPOTHESIS claims true. It makes them explicit, labeled, and testable.
- It does not prevent overclaiming. It makes overclaiming visible — which is the same discipline as the red-team harness, applied to language rather than code.
