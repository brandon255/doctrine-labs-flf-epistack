# Doctrine Labs — Attention & Recovery Corpus

*The evidence base for everything Doctrine Labs builds. Three tiers, every entry DOI'd, every claim labeled, nothing accepted without lineage. This repo is what makes "science-backed" a checkable claim instead of an adjective.*

**Discipline labels (used everywhere, no exceptions):**

| Label | Meaning | Who may use it |
|---|---|---|
| PROVED | Peer-reviewed, replicated, mechanism established | Anyone, in any context |
| BUILT | Running in production, tests passing, behavior verified | Engineering claims only |
| PARTIAL | Real finding, but the pop-science version overstates it | Must carry the precision note |
| CORRELATIONAL | Real association, causality unestablished | Must carry the chicken-and-egg caveat |
| HYPOTHESIS | Plausible mechanism, untested or untestable yet | Must carry "this is what we will measure" |
| PLANNED | Intention, not artifact | Founder's own claims only |

---

## Tier 1 — How the attention economy was built (the adversary's literature)

*The peer-reviewed and documented evidence for how attention capture was engineered. These are the papers the Tristan Harris argument cites — collected here so the counter-science in Tier 2 has a defined opponent.*

**Schema per entry:**
```yaml
id: T1-XXX
title: ""
authors: ""
year: 0
venue: ""
doi: ""
url: ""
label: PROVED | PARTIAL | CORRELATIONAL
claim: ""           # what the paper actually found, one sentence
precision_note: ""  # where the pop-science version overstates it (if applicable)
used_in: []         # which Doctrine Labs artifact cites this
```

**Entries (seeded):**

| ID | Claim (short) | Label |
|---|---|---|
| T1-001 | Fogg, *Persuasive Technology* (2003) — captology framework: computers as persuasive social actors | PROVED |
| T1-002 | Ferster & Skinner (1957) — variable-ratio reinforcement schedules produce highest, most extinction-resistant response rates | PROVED |
| T1-003 | Eyal, *Hooked* (2014) — trigger→action→variable reward→investment loop as product design method | PARTIAL (design framework, not peer-reviewed) |
| T1-004 | Harris, "Race to the bottom of the brainstem" — documented design intent behind engagement optimization | PROVED (as documented intent, not as outcome study) |
| T1-005 | Amiri & HashemiHezarjaribi (2024) — classification of attention-capture mechanics in social platforms | PROVED |

*Full YAML entries for each in `tier1-attention-economy/entries/`.*

---

## Tier 2 — The counter-science (what actually defends attention, agency, and recovery)

*The peer-reviewed evidence for the mechanisms Doctrine Labs products implement. Every entry is load-bearing for at least one product claim.*

**Sub-domains:**
- `attention/` — interruption science, attention residue, flow research, focus protection
- `recovery/` — behavioral activation, self-efficacy, narrative identity, MI, prosocial mechanisms, the daily-rep literature
- `voice/` — prosody, IDS/motherese, co-regulation, vocal emotion detection
- `motivation/` — intrinsic motivation, overjustification, implementation intentions

**Schema per entry (same as Tier 1, plus):**
```yaml
mechanism: ""       # what the finding says about how humans work
product_claim: ""   # what Doctrine Labs claims because of this finding
product_claim_label: PROVED | HYPOTHESIS | PLANNED
```

**Seeded entries by sub-domain:**

**attention/**
| ID | Claim | Label |
|---|---|---|
| T2-A001 | Mark, Gudith & Klocke (2008) — interrupted workers take ~23 min to return to original task, wander through ~2 intervening tasks | PARTIAL (the "23 minutes" is return-to-task, not return-to-focus; the peer-reviewed number is 25 min 26 sec ± 54 min, Mark et al. CHI 2005) |
| T2-A002 | Mark (2023) — average time on one screen before switching: 47 sec (40 sec median); ~half of switches are self-interruptions | PROVED |
| T2-A003 | Leroy (2009) — attention residue: working memory stays on prior task after switching, degrading current performance | PROVED |
| T2-A004 | Kotler / Csikszentmihalyi tradition — flow onset requires 10–25 min of uninterrupted focus; interruption resets the clock | PARTIAL (range, not a single threshold; "20 minutes" is the pop-science compression) |
| T2-A005 | Lieder et al. — "one sec" friction intervention: 57% reduction in target app openings after 6 weeks (peer-reviewed field experiment) | PROVED |
| T2-A006 | Ophir, Nass & Wagner (2009) — heavy media multitaskers worse at task-switching and filtering irrelevant stimuli | CORRELATIONAL (Wagner: causality unestablished) |

**recovery/**
| ID | Claim | Label |
|---|---|---|
| T2-R001 | Bandura (1977, 1997) — mastery experiences (small repeated wins) are the strongest driver of self-efficacy | PROVED |
| T2-R002 | Meichenbaum (1985) — stress inoculation training: manageable stressor exposure builds capacity for larger stressors | PROVED |
| T2-R003 | Williams et al. — behavioral activation: act first, motivation follows; most effective entry point is the easiest action | PROVED |
| T2-R004 | JAMA Psychiatry (2025) — network meta-analysis, 49 trials: high-frequency low-intensity social-skills training strongest for social anxiety | PROVED |
| T2-R005 | McAdams — narrative identity: redemption sequences in self-narrative predict generativity and 4-year mental health trajectories | PROVED (US samples) / CORRELATIONAL (cross-cultural) |
| T2-R006 | Pagano et al. (Stanford) — helping others in recovery predicts 50% improvement in abstinence over 15 months | PROVED |
| T2-R007 | King & Hicks (2021) — meaning = coherence + purpose + mattering; prosocial acts are a primary mattering source | PROVED |
| T2-R008 | Miller & Rollnick — motivational interviewing: discrepancy development ("I notice, you decide") outperforms confrontation | PROVED (human-delivered) / HYPOTHESIS (AI-delivered) |
| T2-R009 | Deci, Koestner & Ryan (1999) — meta-analysis, 128 experiments: expected tangible rewards reduce intrinsic motivation (d ≈ −0.40); verbal affirmation increases it (d ≈ +0.31) | PROVED |
| T2-R010 | Gollwitzer — implementation intentions ("when X, I will do Y"): d ≈ 0.65 on follow-through | PROVED |
| T2-R011 | Pennebaker — expressive writing: moving from low to high self-confrontation improves well-being and health outcomes | PROVED |
| T2-R012 | Frankl — stimulus-response gap: the capacity to choose one's response is the foundation of meaning | PROVED (as construct; clinical validation varies) |

**voice/**
| ID | Claim | Label |
|---|---|---|
| T2-V001 | IDS/motherese: higher f0, wider f0 range, slower tempo, longer pauses, shorter utterances — universal across languages; detected by ML classifiers at >80% accuracy | PROVED |
| T2-V002 | Streeter et al. — yoga vs. matched walking RCT: yoga group shows greater anxiety reduction, proposed mechanism via vagal afferent stimulation | PARTIAL (mechanism proposed, not fully established) |
| T2-V003 | Porges — polyvagal theory: nervous system calibrates safety via prosodic and facial cues from other nervous systems | PARTIAL (foundational theory; digital extension explicitly hypothesis-stage) |
| T2-V004 | Beckes & Coan — social baseline theory: trusted companionship is the brain's expected operating condition, reduces perceived task load | CORRELATIONAL (mostly lab-based) |
| T2-V005 | Voice quality features (jitter, shimmer, HNR) track emotional arousal within ~1 second of onset | PROVED |
| T2-V006 | Chartrand & Bargh (1999) — behavioral mimicry and rapport: humans unconsciously converge prosody in connection | CORRELATIONAL (human-human; AI extension untested) |

**motivation/**
| ID | Claim | Label |
|---|---|---|
| T2-M001 | Lepper, Greene & Nisbett (1973) — overjustification: rewarding children for drawing reduces subsequent free-choice drawing by half | PROVED |
| T2-M002 | Ryan & Deci (2000) — self-determination theory: autonomy, competence, relatedness as intrinsic motivation prerequisites | PROVED |
| T2-M003 | Rotter (1966) — internal locus of control: belief that outcomes are self-caused predicts persistence and well-being | PROVED (construct) / CORRELATIONAL (outcome causality) |

---

## Tier 3 — Founder-primary-source (the n=1 that generated the hypotheses)

*The founder's lived experience, documented as a primary source. This is the origin of the hypotheses, not the proof of them. It belongs in the corpus because it explains *why* these specific mechanisms were chosen — and because the founder's two-year sobriety, the step-work database, and the AA observation record are a real longitudinal dataset, however small.*

**Schema per entry:**
```yaml
id: T3-XXX
type: lived_experience | step_work_artifact | aa_observation | founder_reflection
date_range: ""
anonymized: true
content: ""        # the artifact, or a description of it
hypothesis_generated: ""  # which Tier 2 hypothesis this gave rise to
claim_label: HYPOTHESIS   # always HYPOTHESIS, no exceptions
```

**Seeded entries:**
| ID | Content | Hypothesis generated |
|---|---|---|
| T3-001 | Two-year sobriety record; alcoholic neuropathy; relearned walking; 5-day insomnia stretches; raw-nerve baseline | HYPOTHESIS: daily reps under extreme duress produce cumulative continuity when witnessed |
| T3-002 | Step-work database: 12-step artifacts, per-step datasets, traceable moments of behavioral origin | HYPOTHESIS: narrative identity construction (redemption sequences) is the mechanism of step work |
| T3-003 | AA observation: Tom's "you were a raw nerve — look at you" at month 3–4 | HYPOTHESIS: baseline-holder function requires longitudinal witness with immutable record |
| T3-004 | The 7-Eleven rep: pizza and soda for a stranger counting coins; water bottles behind the car seat; dollar bills ready | HYPOTHESIS: micro-connection (small service acts) is the atomic unit of social-courage building |
| T3-005 | The newcomer payoff observation: "your share helped so much" — months later, without attribution | HYPOTHESIS: delayed horizontal reinforcement is real, unmeasurable, and load-bearing |
| T3-006 | "Progress is invisible but it's compounding" — the billionaire bankruptcy quote from early recovery | HYPOTHESIS: cumulative continuity principle is experienced as invisible-until-suddenly-visible |

---

## The claim register

*The master list of every public claim Doctrine Labs makes, mapped to its evidence tier and label. This is the artifact a journalist, investor, or critic gets when they ask "prove it."*

**Schema per entry:**
```yaml
id: CR-XXX
claim: ""              # the exact public-facing claim
label: PROVED | BUILT | PARTIAL | CORRELATIONAL | HYPOTHESIS | PLANNED
evidence: [T2-R001, T2-R002]  # corpus IDs
product: ""            # which product makes this claim
status: active | under_review | retired
```

**Format for the register (populated as products ship):**

| ID | Claim | Label | Evidence | Product | Status |
|---|---|---|---|---|---|
| CR-001 | "Small daily reps build self-efficacy and compound invisibly" | PROVED | T2-R001, T2-R002 | Zoe Standard | active |
| CR-002 | "Prosocial acts reduce anxiety and improve mood" | PROVED | T2-R004, T2-R006 | Zoe Standard | active |
| CR-003 | "Being witnessed turns events into identity" | PROVED | T2-R005, T2-R007 | Zoe Standard | active |
| CR-004 | "Zoe's voice, engineered on the IDS register, produces measurable state improvement in adult users" | HYPOTHESIS | T2-V001, T2-V003, T2-V004 | Zoe (voice) | under_review |
| CR-005 | "AI-delivered MI-style discrepancy produces the same behavior change as human-delivered MI" | HYPOTHESIS | T2-R008 | Zoe Section 8 | under_review |
| CR-006 | "Our success metric is that users need Zoe less over time" | HYPOTHESIS | T2-R009, T2-R002 | RAIL 3 | active |
| CR-007 | "Tangible expected rewards reduce intrinsic motivation; we therefore do not gamify the rep" | PROVED | T2-R009, T2-M001 | RAIL 3 | active |
| CR-008 | "Simulated co-regulation via AI voice calms the human nervous system" | HYPOTHESIS | T2-V003, T2-V004 | Zoe (voice) | under_review |
| CR-009 | "The arc reflection (baseline-holder function) produces measurable behavior change" | HYPOTHESIS | T3-003, T2-R005 | RAIL 3 | under_review |
| CR-010 | "Flow requires 10–25 minutes of uninterrupted focus; our focus ramp protects this window" | PARTIAL | T2-A004 | Focus Ramp | active |

---

## Directory structure

```
doctrine-labs-attention-corpus/
├── README.md                    # this file
├── tier1-attention-economy/
│   ├── README.md               # sub-domain intro + schema
│   └── entries/                # YAML files, one per entry (T1-001.yaml …)
├── tier2-counter-science/
│   ├── README.md
│   ├── attention/              # T2-A001.yaml …
│   ├── recovery/               # T2-R001.yaml …
│   ├── voice/                  # T2-V001.yaml …
│   └── motivation/             # T2-M001.yaml …
├── tier3-founder-primary-source/
│   ├── README.md
│   └── entries/                # T3-001.yaml …
├── claim-register/
│   ├── claims.yaml             # the master register
│   └── schema.yaml             # the register schema itself
└── epistack-integration.md     # how this feeds the FLF Epistack engine
```

---

*Corpus v1 — seeded from the Doctrine Labs / Zoe build sessions, September 2026. Every entry is a starting point, not a final word. The corpus grows as the products generate data, and Tier 3 entries are anonymized before they enter.*
