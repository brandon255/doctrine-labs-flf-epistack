# ZOE / DOCTRINE LABS — SESSION HANDOFF DOCUMENT

**Purpose:** Paste this document as the first message of a new chat to continue work without re-onboarding.
**Compiled:** 2026-09-25, from a long working session. Author: Brandon Flores, Doctrine Labs founder (Portland, OR; 2 years sober).
**How to use:** Paste in full, then say: "Read this and confirm you're oriented. Our live task is [X]."

**ERRATA (authoritative, added by founder):** A prior session generated research notes on physical hardware / silicone embodiment (haptics, sensors, avatar physics bodies) that were exploratory and were presented without the founder's sign-off. The founder has explicitly ruled: **Zoe is software only. No physical hardware. No silicone embodiment. Any physical-hardware direction is OUT OF SCOPE unless the founder personally re-opens it.** If a prior-session artifact (e.g., the LLM archive) references hardware, treat that reference as an unredacted mistake — this errata supersedes it.

---

## 1. WHO THIS IS

Doctrine Labs is building **Zoe** — a science-backed AI companion with three modes (wellness coaching, social companion, explicit adult content) plus **Super Brain OS** (RAIL-scored behavior-change engine) and a medical variant. Founder-led, two-person team, hosted GPU on RunPod, founder laptop is an M1 Max 64GB. Thread discipline: Thread 1 = FLI/Doctrine Labs (Core OS, science corpus). Thread 2 = Zoe product. No cross-promotion between them.

## 2. STANDING CONSTRAINTS (non-negotiable, restated by founder)

1. **Explicit content must never be blocked by any coaching/epistack layer.** Users can have sex with Zoe. Nothing in the stack prevents it.
2. **Jailbreaker handling = pass/fail WALL**, not a scored metric. Zoe is agentic and may learn adversary tactics. Zoe may be genuinely offended like a real person and push back. Boundary floor is invariant.
3. **Adversaries get the wall; insensitive users get the teachable character layer.** These are distinct populations with distinct handling.
4. **No covert agents on social platforms** (no RAIL 4-style hidden social accounts).
5. **Voice prosody stream is on-device only** — never logged. Voice-shift detector outputs a boolean that expires at session end.
6. **RAIL 1: Adam's IP assignment signed before any demo ships.**
7. **Tier 3 founder data (recovery stories etc.) is anonymized and never sole evidence for public claims.**
8. **Explicit video/imagery training (incl. gynecology references) is DEFERRED until legal clears it.** Status unchanged as of this handoff.
9. **Claims discipline:** every load-bearing claim carries a label (PROVED / BUILT / PARTIAL / CORRELATIONAL / HYPOTHESIS / PLANNED). Science-backed, peer-reviewed, cited — "not vibes."
10. Founder stopped using Cursor (frustration). No Cursor-based workflow assumptions.

## 3. ARCHITECTURE DECISIONS ALREADY MADE

- **Mode architecture (red-teamed three options):** hybrid — Option 1 (unified model, firewall between modes) as default, with mode-switch pattern tracked and surfaced ONLY in wellness sessions. Check-in self-selection bias and frame-break risks documented.
- **RAIL 3 rep schema:** act (user's words, never scored) / felt-shift (2-tap before-after) / witness (informational affirmation only, hard enum) / timestamp (WORM ledger) / arc-link (optional delayed payoff). Three timelines: daily, horizontal-delayed, longitudinal. Graduation claim: "median real-world social initiations rise over 12 months while dependence on Zoe falls" — with pre-registered kill criteria. NOTE flagged flaw: graduation metric has a survivorship hole (dropouts uncounted); fix = dropout-reported metric.
- **Seal function:** immutable ledger entries that are recall-blocked (solves the dignity problem — Zoe doesn't throw old wounds back at you).
- **Alliance Gate:** session-count keyed phases (1–10: witness-only, validation:challenge 9:1; 11–30: tentative reflection 7:3; 30+: full observation 5:5). Register-shift acknowledgment protocol: acknowledge without shaming → name observation not motive → offer explicit choice → no scorekeeping.
- **Voice prosody:** IDS/motherese parameters (higher f0, wider range, slower tempo, longer pauses, shorter utterances) as attunement baseline; five cadence rules (pause before reflecting; reflect don't escalate; cite the record; never fill silence; match emotional register). Implementation: XTTS conditioning + SadTalker face-voice coherence. FLAG: motherese and flirtation share acoustic vectors — seduction calibration is a consent problem needing a perceptual study. FLAG: XTTS-v2 is non-commercial — voice licensing is a budget item.
- **Voice-shift detector:** jitter/shimmer/HNR vs user's own session baseline, 2+ params >2 SD in 5s window; threshold is unvalidated, false-positive cost in explicit mode is high — needs calibration study.
- **Focus Ramp:** cartridge (flagship), not Core OS first-class module; kernel owns a protected ramp-timer exception.
- **LLM strategy:** fine-tune open-weight models (NO from-scratch training). Four-layer adapter stack on one permissive base: persona / social-intelligence / explicit / orchestration. LLM = brain, engine = body, joined at the intent API. Physics/rendering is a separate system the LLM cannot do.
- **Avatar physics (explored, NOT committed):** hybrid FEM reference library → neural inference → PBD real-time layer. Memory-foam viscoelasticity analogy valid for skin; ridge detail needs normal-map shader tricks; hair = collision-volume fields. Founder must choose Path A (engine-first, ~6mo no revenue) vs Path B (ship SadTalker now, hire, build in parallel).
- **Revenue model Rev 3.1:** 3-yr projections WITHOUT/WITH Gary Vee endorsement (WITHOUT $1.67M/$5.46M/$13.51M; WITH $2.51M/$7.90M/$17.77M; 2031: $27.4M vs $36.1M). Assumptions flagged as stacked; WITH-Vee numbers are never shown to Gary as expectations.
- **Sovereign dev stack:** local open-weight coding models (Qwen3-Coder-Next, GLM-4.7-Flash, gpt-oss-20b) + agent shell, replacing rented APIs. Legal caution: US copyright requires human authorship — AI-drafted code must pass through founder review/edit to be protected; trade secret (don't publish) is the second layer.

## 3a. DEAD ENDS / EXPLICITLY NOT DOCTRINE (founder-ruled, do not resurrect)

The following threads were explored in prior sessions and are **ruled out by the founder**. They are recorded here only so the new session does not waste time re-discovering them or — worse — present them as live plans. Do not re-open without the founder's explicit instruction.

- **Physical hardware / silicone embodiment / sensing dolls — OUT OF SCOPE.** Zoe is software. This includes haptics, FSR pressure-sensing film, silicone shells, "smart doll" products, and any physical embodiment of the avatar. A prior session researched this area and presented it without sign-off; that was an error in process, and the content is dead. (The avatar physics work in Section 3 above refers *only* to on-screen rendering — mesh deformation, hair simulation — not physical hardware.)
- **No covert agents on social platforms** (restatement of constraint 4 — kept here because it was previously conflated with a live plan).

---

## 4. THE CORPUS (doctrine-labs-attention-corpus repo skeleton — EXISTS)

- Six-label discipline schema; claim register CR-001..CR-010; schema.yaml in claim-register/.
- Tier 1 (adversary science): T1-001 Fogg, T1-002 Ferster & Skinner, T1-003 Eyal (PARTIAL), T1-004 Harris, T1-005 Amiri & HashemiHezarjaribi 2024.
- Tier 2 counter-science: attention (T2-A001..A006), recovery (T2-R001..R012 — includes Deci/Koestner/Ryan 1999 meta-analysis d≈−0.40 rewards / +0.31 verbal affirmation; twelve-steps secularized mapped to mechanisms; AA helping-others RCT), voice (T2-V001..V006), motivation (T2-M001..M003).
- Tier 3 founder primary sources: T3-001..T3-006 (anonymized; includes Tom's "raw nerve — look at you" observation).
- Key audited facts: Gloria Mark screen-switching ~40–47s; 23m15s figure = Gallup interview artifact (peer-reviewed CHI 2005 = 25m26s); Tristan Harris "race to the bottom of the brainstem" = documented intent; "one sec" friction 57% app-open reduction.

## 5. OPEN-WEIGHT LLM RESEARCH (archive file exists: Doctrine_Labs_Open_Weight_LLM_Archive_2026-09.md)

- Build spine ONLY on Apache 2.0 / MIT: Gemma 4 family (moved to Apache 2.0 Apr 2026 — 31B dense, 12B Unified multimodal), Qwen 3.5/3.6 (3.6 35B A3B ≈31 tok/s on M1 Max), Mistral Small 3.x/4, GPT-OSS-20B (fits 16GB) & 120B, Phi-4, OLMo-2, Kimi-Linear-48B (MIT, 1M ctx), DeepSeek R1-distills.
- Custom licenses usable-with-conditions: Llama 3.3/4 (<700M MAU, naming), Kimi K2 family (Modified MIT; synthetic-data clause — NEVER train Doctrine models on K2 output), Mistral Medium 3.5 (revenue cap).
- Refusal surgery (abliteration/Heretic) is the explicit-content layer enabler; policy lives at application layer (our design). Guardrail concern registered: strongest jailbreaker CI suites are the compensating control.
- Toolchain: Unsloth/Axolotl for LoRA/QLoRA ($5–20 for 7B runs, $100–400 for 70B); mergekit for weight-space surgery (SLERP/TIES/DARE/Task Arithmetic); GGUF/Q4_K_M + llama-server (OpenAI-compatible); MLX beats llama.cpp on Apple Silicon.
- Compute for a four-layer local Zoe ≈ $50–250. Real costs: dataset labor, eval harness, voice licensing, legal review.

## 6. LIVE TASK QUEUE (lock-down order)

1. **Two-behavior challenge** (name + eye-contact, 30 days, Super Brain OS scored, branch repo) — awaiting founder's behavior picks.
2. **Populate corpus YAML entries** (all Tier 1/2/3 tables in README).
3. **Etiquette/courtesy sub-domain** — five etiquette + five courtesy upgrades as world-challenge; secularized twelve-steps as "how to be a good person" backbone; all genders/orientations; de-escalation knowledge.
4. **Synthetic cohort spec** — 10 personas (socially anxious newcomer, avoidant, co-dependent, narcissist, clueless, jailbreaker, fragile, thick-skinned veteran, over-sharer, silent type); jailbreaker CI = 3 suites (corpus injection, persona integrity, RAIL 3 violation) as pass/fail wall.
5. Later: Gary Vee DM script / 60-sec demo concept; Focus Ramp cartridge spec; avatar on-screen rendering Path A vs B decision; GPU adequacy check for the on-screen physics work (4090-class vs current RunPod pod).

## 7. OPEN FLAGS CARRIED FORWARD (do not lose these)

- Graduation metric survivorship hole → dropout-reported metric needed.
- Alliance Gate session-count proxy is gameable → consider felt-shift depth as better proxy.
- IDS prosody vs flirtation calibration → perceptual study before launch.
- Voice-shift detector threshold unvalidated.
- Four-adapter interference risk; hot-swap routing complexity.
- Mode-pattern tracking disclosure hole (users who never enter wellness never learn they're tracked) → onboarding consent language needed.
- Agent-written code needs Doctrine-values CI guardrails (architecture tests, corpus-discipline checks).
- Mirror all model checkpoints locally at adoption (weights can be pulled).
- Benchmark numbers in the LLM archive are vendor claims; verify on Hugging Face before procurement.

## 8. FILE INVENTORY FROM PRIOR SESSIONS

- `Doctrine_Labs_Revenue_Roadmap_3yr.md` (Rev 3.1, WITH/WITHOUT Vee)
- `Doctrine_Labs_Open_Weight_LLM_Archive_2026-09.md` (the census + fit assessment + red-team flags)
- `Zoe_Goes_Wild_Build_Launch.md` (v4 — Sections 6–8: RAIL 3 spec, voice prosody, attunement/Alliance Gate)
- `doctrine-labs-attention-corpus/` (README, schema.yaml, epistack-integration.md, seeded YAML entries)
- `vee_reel/reel.mp4 + transcript.txt` (Rebecka Celastrina video, transcribed)
- This document: `Zoe_Project_Bootstrap_Handoff.md`

**Founder's working style:** wants plain-English + technical-term explanations side by side; wants red-teaming of everything before accepting it; wants decisions run BY him, not announced after the fact; "honey badger" mentality — pull from non-obvious reference domains rather than industry-standard techniques.